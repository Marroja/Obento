﻿using System;
using System.Windows.Forms;
using System.Windows;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Text.RegularExpressions;

public class PanelControl : Form
{
    static string nomFuente;
    static bool modoOscuro;
    static int numDir;
    static public void Main()
    {
        if (File.Exists("conf.txt"))
        {

            string[] config = File.ReadAllLines("conf.txt");
            if(config.Length == 3)
            {
                int numTotDirs;
                nomFuente = config[0];

                numDir = Int32.Parse(config[1]);

                if ("1" == config[2])
                {
                    modoOscuro = true;
                    Console.WriteLine("Iniciando modo oscuro");
                }
                else
                {
                    modoOscuro = false;
                }

                if (Directory.Exists("voc/"))
                {
                    string[] archivos = Directory.GetDirectories("voc");
                    numTotDirs = archivos.Length;
                    if(numDir < numTotDirs)
                    {
                    }
                    else
                    {
                        numDir = -1;
                    }
                }
                else
                {
                    numDir = -1;
                }

                
            }
            else
            {
                MessageBox.Show("El archivo de configuración se ha reiniciado");
                string[] texto = { "TakaoMincho", "-1", "0" };
                File.WriteAllLines("conf.txt", texto);
            }
        }
        else
        {
            MessageBox.Show("Se ha generado archivo de configuración 'conf.txt'");
            string[] texto = { "TakaoMincho", "-1", "0" };
            File.WriteAllLines("conf.txt", texto);
        }

        Application.EnableVisualStyles();
        Application.Run(new PanelControl(nomFuente, modoOscuro, numDir));
    }

    ListBox LBDirectorio;
    TextBox TBNuevoDir;

    int tamFuente = 12;
    string directorioVoc = "";
    string textoNuevoDir = "";
    string[] archivos = { };
    ComboBox CBFuentes;
    Herr her = new Herr();

    public PanelControl(string nomFuente, bool modoOscuro, int numDir)
    {
        this.Icon = new Icon("obento.ico");
        MaximizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        Button BEstudio = new Button();
        Button BGuardar = new Button();
        Button BActualizar = new Button();
        LBDirectorio = new ListBox();
        Label LElija = new Label();
        Button BAgregarDir = new Button();
        TBNuevoDir = new TextBox();

        this.Controls.Add(TBNuevoDir);
        this.Controls.Add(BEstudio);
        this.Controls.Add(LElija);
        this.Controls.Add(LBDirectorio);
        this.Controls.Add(BGuardar);
        this.Controls.Add(BAgregarDir);
        this.Controls.Add(BActualizar);

        //Herr her = new Herr();
        this.Width = 500;
        this.Height = 400;
        this.Text = "Obento~";
        this.BackColor = System.Drawing.Color.LightGray;

        LElija.Left = 10;
        LElija.Top = 20;
        LElija.ForeColor = System.Drawing.Color.Black;
        LElija.Width = 400;
        LElija.Height = 30;

        Label LAgregar = new Label();
        LAgregar.Left = 10;
        LAgregar.Top = 230;
        LAgregar.Width = 400;
        LAgregar.Height = 30;
        LAgregar.ForeColor = System.Drawing.Color.Black;
        this.Controls.Add(LAgregar);

        Label LFuente = new Label();
        LFuente.Left = 10;
        LFuente.Top = 300;
        LFuente.Width = 100;
        LFuente.Height = 20;
        LFuente.ForeColor = System.Drawing.Color.Black;
        this.Controls.Add(LFuente);

        CBFuentes = new ComboBox();
        CBFuentes.Left = 10;
        CBFuentes.Top = 320;
        //CBFuentes.AllowDrop = true;
        CBFuentes.SelectedIndexChanged += CBFuentes_Cambio;
        this.Controls.Add(CBFuentes);

        if (Directory.Exists("voc/"))
        {
            archivos = Directory.GetDirectories("voc");
        }
        else
        {
            Directory.CreateDirectory("voc");
            this.Refresh();
        }

        InstalledFontCollection fontCol = new InstalledFontCollection();
        for (int x = 0; x < fontCol.Families.Length; x++)
        {
            CBFuentes.Items.Add(fontCol.Families[x].Name);
        }

        LBDirectorio.DataSource = archivos;
        LBDirectorio.Left = 10;
        LBDirectorio.Top = 50;
        LBDirectorio.Width = 300;
        LBDirectorio.Height = 160;
        LBDirectorio.HorizontalScrollbar = true;
        LBDirectorio.SelectedValueChanged += LBDirectorio_CambioDirectorio;
        LBDirectorio.SelectedIndex = numDir;
        LBDirectorio.ForeColor = System.Drawing.Color.Black;

        TBNuevoDir.Width = 300;
        TBNuevoDir.Height = 30;
        TBNuevoDir.Left = 10;
        TBNuevoDir.Top = 250;

        BActualizar.Left = 340;
        BActualizar.Top = 125;
        BActualizar.Width = 120;
        BActualizar.Height = 25;
        BActualizar.BackColor = System.Drawing.Color.WhiteSmoke;
        BActualizar.ForeColor = System.Drawing.Color.Black;
        BActualizar.Click += BActualizar_Click;

        BGuardar.Width = 120;
        BGuardar.Left = 340;
        BGuardar.Top = 50;
        BGuardar.UseCompatibleTextRendering = true;
        BGuardar.Click += BGuardar_Click;
        BGuardar.BackColor = System.Drawing.Color.WhiteSmoke;
        BGuardar.ForeColor = System.Drawing.Color.Black;

        BAgregarDir.Width = 120;
        BAgregarDir.Left = 340;
        BAgregarDir.Top = 250;
        BAgregarDir.UseCompatibleTextRendering = true;
        BAgregarDir.Click += BAgregarDir_Click;
        BAgregarDir.BackColor = System.Drawing.Color.WhiteSmoke;
        BAgregarDir.ForeColor = System.Drawing.Color.Black;

        BEstudio.Width = 120;
        BEstudio.Left = 340;
        BEstudio.Top = 75;
        BEstudio.UseCompatibleTextRendering = true;

        BEstudio.Click += BEstudio_Click;
        BEstudio.BackColor = System.Drawing.Color.WhiteSmoke;
        BEstudio.ForeColor = System.Drawing.Color.Black;

        if(LBDirectorio.Items.Count > 0)
        {
            directorioVoc = LBDirectorio.SelectedValue.ToString();
        }
        

        Button BBorrarInfo = new Button();
        BBorrarInfo.Left = 340;
        BBorrarInfo.Top = 150;
        BBorrarInfo.Width = 120;
        BBorrarInfo.Height = 25;
        BBorrarInfo.BackColor = System.Drawing.Color.WhiteSmoke;
        BBorrarInfo.ForeColor = System.Drawing.Color.Black;

        BBorrarInfo.Click += BBorrarInfo_Click;

        this.Controls.Add(BBorrarInfo);
        //nomFuente = CBFuentes.SelectedItem.ToString();

        LElija.Font = new Font(nomFuente, tamFuente + 3);
        LAgregar.Font = new Font(nomFuente, tamFuente);
        LFuente.Font = new Font(nomFuente, tamFuente);
        BBorrarInfo.Font = new Font(nomFuente, tamFuente);
        BGuardar.Font = new Font(nomFuente, tamFuente);
        BAgregarDir.Font = new Font(nomFuente, tamFuente);
        BEstudio.Font = new Font(nomFuente, tamFuente);
        BActualizar.Font = new Font(nomFuente, tamFuente);

        if (File.Exists("lingua.txt"))
        {
            string[] traducciones = File.ReadAllLines("lingua.txt",System.Text.Encoding.UTF8);

            LElija.Text = her.ExtraerTraduccion(0);
            LAgregar.Text = her.ExtraerTraduccion(1);
            LFuente.Text = her.ExtraerTraduccion(2);
            BGuardar.Text = her.ExtraerTraduccion(3);
            BEstudio.Text = her.ExtraerTraduccion(4);
            BActualizar.Text = her.ExtraerTraduccion(5);
            BBorrarInfo.Text = her.ExtraerTraduccion(6);
            BAgregarDir.Text = her.ExtraerTraduccion(7);
        }
        else
        {
            LElija.Text = "Elija el directorio:";
            LAgregar.Text = "Agregar directorio (sin 'voc/'):";
            LFuente.Text = "Fuente:";
            BGuardar.Text = "Agregar Voc";
            BEstudio.Text = "Estudiar";
            BActualizar.Text = "Actualizar Lib";
            BBorrarInfo.Text = "Reiniciar";
            BAgregarDir.Text = "Agregar";
        }
    }


    void BActualizar_Click(object sender, EventArgs e)
    {

        string[] ArregloVoc = Directory.GetFiles(directorioVoc, "*.txt", SearchOption.TopDirectoryOnly);
        string nuevaLista = "";
        //Console.WriteLine(""+ArregloVoc[0]);

        if(ArregloVoc.Length == 1)
        {
            return;
        }

        for (int i = 1; i < ArregloVoc.Length; i++)
        {
            string s = ArregloVoc[i];
            int pDesde = s.IndexOf(directorioVoc) + directorioVoc.Length;
            int pHasta = s.LastIndexOf(".txt");
            string ss = s.Substring(pDesde + 1, pHasta - pDesde - 1);
            //Console.WriteLine(ss+":"+ss.Length);
            if(i == 1)
            {
                nuevaLista += ss+":0";
            }
            else
            {
                nuevaLista += "\n" + ss+":0";
            }
        }
        File.WriteAllText(directorioVoc + "/00.txt", nuevaLista);
        MessageBox.Show("Se ha reiniciado la lista de vocabulario.");
    }
    void BBorrarInfo_Click(object sender, EventArgs e)
    {

        string texto = File.ReadAllText(directorioVoc + "/00.txt");
        char bandera = '\n';
        Console.WriteLine(texto);
        File.WriteAllText(directorioVoc + "/00.txt", "");
        string[] arrTexto = texto.Split(bandera);
        texto = "";
        string s = "";

        for (int i = 0; i < arrTexto.Length; i++)
        {
            //Console.WriteLine("Entró a for");
            s = arrTexto[i];
            int iDosP = s.IndexOf(":");
            string numVeces = s.Substring(iDosP + 1, s.Length - iDosP - 1);
            s = s.Replace(numVeces, "0");
            if (i == 0)
            {
                texto += s;
            }
            if (i > 0)
            {
                texto += "\n" + s;
            }
            //Console.Write(texto);
        }
        File.WriteAllText(directorioVoc + "/00.txt", texto);
        MessageBox.Show("Se ha reiniciado la cuenta de estudio de " + directorioVoc);
    }
    void CBFuentes_Cambio(object sender, EventArgs e)
    {
        nomFuente = CBFuentes.SelectedItem.ToString();

        this.Refresh();

        if (File.Exists("conf.txt"))
        {
            her.CambiaArchivoConf("conf.txt", 0, CBFuentes.SelectedItem.ToString());
        }
    }
    void BEstudio_Click(object sender, EventArgs e)
    {
        //directorioVoc = "voc/"+(string)(LBDirectorio.SelectedText);

        if (File.ReadAllText(directorioVoc + "/00.txt") != "")
        {
            //Console.WriteLine("Sí hay palabras");
            AreaDeEstudio AdE = new AreaDeEstudio(nomFuente, directorioVoc, modoOscuro);
            AdE.Show();
        }
        else
        {
            MessageBox.Show("No hay palabras a estudiar, agruegue palabras primero.");
        }
    }
    void BAgregarDir_Click(object sender, EventArgs e)
    {
        if (TBNuevoDir.Text != "")
        {
            Directory.CreateDirectory("voc/" + TBNuevoDir.Text);
            //File.Create("voc/"+TBNuevoDir.Text+"/lista.txt");
            File.WriteAllText("voc/" + TBNuevoDir.Text + "/00.txt", "");
            TBNuevoDir.Text = "";
            archivos = Directory.GetDirectories("voc");
            LBDirectorio.DataSource = archivos;
            this.Refresh();
            //this.Update();
        }
    }
    void BGuardar_Click(object sender, EventArgs e)
    {
        directorioVoc = LBDirectorio.SelectedValue.ToString();
        RegistroDiccionario RD = new RegistroDiccionario(nomFuente, directorioVoc);
        RD.Show();
    }
    void LBDirectorio_CambioDirectorio(object sender, EventArgs e)
    {
        directorioVoc = LBDirectorio.SelectedValue.ToString();
        her.CambiaArchivoConf("conf.txt", 1, ""+LBDirectorio.SelectedIndex);
    }

}

public class RegistroDiccionario : Form
{
    string nomFuente;
    string directorioVoc;
    TextBox TBEntradaEstudio, TBExplicacion, TBFonetico, TBEntradaMaterna, TBOracionEjemplo;
    Herr her;
    Form FSobreE;
    Button BGuardar;


    string archivo;

    public RegistroDiccionario(string nomFuente, string directorioVoc)
    {
        this.Icon = new Icon("obento.ico");
        this.MaximizeBox = false;
        this.KeyPreview = true;
        this.KeyDown += Form_TeclaPresionada;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.nomFuente = nomFuente;
        this.directorioVoc = directorioVoc;
        her = new Herr();
        BackColor = System.Drawing.Color.LightGray;
        Width = 540;
        Height = 600;

        Label LNuevaPalabra = new Label();
        Formato(LNuevaPalabra, "e");
        TBEntradaEstudio = new TextBox();
        Formato(TBEntradaEstudio, "e");

        Label LTradLiteral = new Label();
        Formato(LTradLiteral, "m");
        TBEntradaMaterna = new TextBox();
        Formato(TBEntradaMaterna, "m");

        Label LFonetica = new Label();
        Formato(LFonetica, "k");
        TBFonetico = new TextBox();
        Formato(TBFonetico, "k");

        Label LEjemplo = new Label();
        Formato(LEjemplo, "ej");
        TBOracionEjemplo = new TextBox();
        Formato(TBOracionEjemplo, "ej");

        Label LExplicacion = new Label();
        Formato(LExplicacion, "expl");
        TBExplicacion = new TextBox();
        Formato(TBExplicacion, "expl");

        BGuardar = new Button();
        BGuardar.Width = 120;
        BGuardar.Left = 380;
        BGuardar.Top = 520;
        BGuardar.UseCompatibleTextRendering = true;
        this.Controls.Add(BGuardar);
        BGuardar.Font = new Font(nomFuente, 12);
        BGuardar.Click += BGuardar_Click;
        BGuardar.BackColor = System.Drawing.Color.WhiteSmoke;
        BGuardar.ForeColor = System.Drawing.Color.Black;

        Button BEditarEntrada = new Button();
        BEditarEntrada.Width = 120;
        BEditarEntrada.Left = 220;
        BEditarEntrada.Top = 520;

        BEditarEntrada.UseCompatibleTextRendering = true;
        this.Controls.Add(BEditarEntrada);
        BEditarEntrada.Font = new Font(nomFuente, 12);
        BEditarEntrada.Click += BEditarEntrada_Click;
        BEditarEntrada.BackColor = System.Drawing.Color.WhiteSmoke;
        BEditarEntrada.ForeColor = System.Drawing.Color.Black;

        if (File.Exists("lingua.txt"))
        {
            this.Text = her.ExtraerTraduccion(8);
            BGuardar.Text = her.ExtraerTraduccion(9);
            BEditarEntrada.Text = her.ExtraerTraduccion(10);
            LNuevaPalabra.Text = her.ExtraerTraduccion(11);
            LTradLiteral.Text = her.ExtraerTraduccion(12);
            LFonetica.Text = her.ExtraerTraduccion(13);
            LEjemplo.Text = her.ExtraerTraduccion(14);
            LExplicacion.Text = her.ExtraerTraduccion(15);
        }
        else
        {
            this.Text = "Área de registro";
            BGuardar.Text = "Agregar palabras";
            BEditarEntrada.Text = "Editar";
            LNuevaPalabra.Text = "Nueva palabra:";
            LTradLiteral.Text = "Traducción literal:";
            LFonetica.Text = "Fonética:";
            LEjemplo.Text = "Oraciones ejemplo:";
            LExplicacion.Text = "Explicación adicional:";
        }
    }

    void BEditarEntrada_Click(object sender, EventArgs e)
    {
        archivo = directorioVoc + "/" + TBEntradaEstudio.Text + ".txt";
        if (File.Exists(archivo))
        {
            LlenarRegistro(archivo);
        }
    }

    void Form_TeclaPresionada(object sender, KeyEventArgs e)
    {
        if (e.Modifiers == Keys.Control && e.KeyCode == Keys.Enter)
        {
            BGuardar.PerformClick();
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        if (e.KeyCode == Keys.Enter)
        {
            SendKeys.SendWait("{Tab}");
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
    }

    void BGuardar_Click(object sender, EventArgs e)
    {
        if (TBFonetico.Text == "")
        {
            TBFonetico.Text = "-";
        }
        if (TBExplicacion.Text == "")
        {
            TBFonetico.Text = "-";
        }
        if (TBEntradaMaterna.Text == "")
        {
            TBEntradaMaterna.Text = "-";
        }
        if (TBOracionEjemplo.Text == "")
        {
            TBOracionEjemplo.Text = "-";
        }

        archivo = directorioVoc + "/" + TBEntradaEstudio.Text + ".txt";
        if (!File.Exists(archivo))
        {
            FileStream fs = File.Create(archivo);
            //File.Dispose();

            string texto = "[N]0[/N]\n"
            + "[V]" + TBEntradaEstudio.Text + "[/V]\n"
            + "[M]" + TBEntradaMaterna.Text + "[/M]\n"
            + "[F]" + TBFonetico.Text + "[/F]\n"
            + "[O]" + TBOracionEjemplo.Text + "[/O]\n"
            + "[E]" + TBExplicacion.Text + "[/E]\n";
            fs.Dispose();

            StreamWriter SW = new StreamWriter(archivo);
            SW.Write(texto);
            SW.Dispose();

            string entrada;
            if (File.ReadAllText(directorioVoc + "/00.txt") == "")
            {
                entrada = TBEntradaEstudio.Text + ":0";
            }
            else
            {
                entrada = "\n"+TBEntradaEstudio.Text + ":0";
            }

            SW = File.AppendText(directorioVoc + "/00.txt");
            SW.Write(entrada);
            SW.Dispose();

            TBEntradaEstudio.Text = "";
            TBEntradaMaterna.Text = "";
            TBExplicacion.Text = "";
            TBOracionEjemplo.Text = "";
            TBFonetico.Text = "";

        }
        else if (File.Exists(archivo))
        {

            FSobreE = new Form();

            Button BSobreE = new Button();
            BSobreE.Text = "Sobreescribir";
            BSobreE.BackColor = System.Drawing.Color.LightGray;
            BSobreE.ForeColor = System.Drawing.Color.Black;
            BSobreE.Height = 30;
            BSobreE.Width = 120;
            BSobreE.Left = 40;
            BSobreE.Top = 30;
            BSobreE.Click += BSobreE_Click;

            Button BEditar = new Button();
            BEditar.Text = "Editar";
            BEditar.BackColor = System.Drawing.Color.LightGray;
            BEditar.ForeColor = System.Drawing.Color.Black;
            BEditar.Height = 30;
            BEditar.Width = 120;
            BEditar.Left = 40;
            BEditar.Top = 100;
            BEditar.Click += BEditar_Click;
            //BEditar.FlatStyle = FlatStyle.System;

            FSobreE.Width = 200;
            FSobreE.Height = 220;
            FSobreE.Show();

            FSobreE.Controls.Add(BSobreE);
            FSobreE.Controls.Add(BEditar);
        }
    }
    void BSobreE_Click(object sender, EventArgs e)
    {
        File.Delete(archivo);
        FileStream fs = File.Create(archivo);

        if (TBFonetico.Text == "")
        {
            TBFonetico.Text = "-";
        }
        if (TBExplicacion.Text == "")
        {
            TBFonetico.Text = "-";
        }
        if (TBEntradaMaterna.Text == "")
        {
            TBEntradaMaterna.Text = "-";
        }
        if (TBOracionEjemplo.Text == "")
        {
            TBOracionEjemplo.Text = "-";
        }

        string texto = "[N]0[/N]\n"
        + "[V]" + TBEntradaEstudio.Text + "[/V]\n"
        + "[M]" + TBEntradaMaterna.Text + "[/M]\n"
        + "[F]" + TBFonetico.Text + "[/F]\n"
        + "[O]" + TBOracionEjemplo.Text + "[/O]\n"
        + "[E]" + TBExplicacion.Text + "[/E]\n";
        fs.Dispose();

        StreamWriter SW = new StreamWriter(archivo);
        SW.Write(texto);
        SW.Dispose();

        string entrada = "";

        if (!File.Exists(directorioVoc + "/00.txt"))
        {
            File.WriteAllText(directorioVoc + "/00.txt", "");
        }

        if (File.ReadAllText(directorioVoc + "/00.txt").Contains(TBEntradaEstudio.Text))
        {
            //entrada = TBEntradaEstudio.Text+":0";
        }
        else
        {
            entrada = "\n"+TBEntradaEstudio.Text + ":0";
            SW = File.AppendText(directorioVoc + "/00.txt");
            SW.Write(entrada);
            SW.Dispose();
        }

        TBEntradaEstudio.Text = "";
        TBEntradaMaterna.Text = "";
        TBExplicacion.Text = "";
        TBOracionEjemplo.Text = "";
        TBFonetico.Text = "";

        FSobreE.Dispose();
    }

    void BEditar_Click(object sender, EventArgs e)
    {
        FSobreE.Dispose();
        LlenarRegistro(archivo);
    }

    public void LlenarRegistro(string archivo)
    {
        Herr her = new Herr();
        string todoTexto = her.ImportarTexto(archivo);
        RegistroDiccionario RD = new RegistroDiccionario(nomFuente, directorioVoc);
        RD.Controls[1].Text = her.ExtraerTexto(todoTexto, "V");
        RD.Controls[3].Text = her.ExtraerTexto(todoTexto, "M");
        RD.Controls[5].Text = her.ExtraerTexto(todoTexto, "F");
        RD.Controls[7].Text = her.ExtraerTexto(todoTexto, "O");
        RD.Controls[9].Text = her.ExtraerTexto(todoTexto, "E");

        RD.Show();
    }

    public void Formato(TextBox TB, string tipo)
    {
        TB.Left = 12;
        TB.Font = new Font(nomFuente, 20);
        //TB.FlatStyle = FlatStyle.Flat;

        if (tipo == "e")
        {
            TB.Top = 35;
            TB.Width = 240;
        }
        if (tipo == "m")
        {
            TB.Top = 100;
            TB.Width = 240;
        }
        if (tipo == "k")
        {
            TB.Top = 100;
            TB.Left += 300;
            TB.Width = 200;
        }
        if (tipo == "ej")
        {
            TB.Multiline = true;
            TB.Top = 170;
            TB.Height = 90;
            TB.Width = 500;
        }
        if (tipo == "expl")
        {
            TB.Multiline = true;
            TB.Top = 290;
            TB.Height = 220;
            TB.Width = 500;
        }
        this.Controls.Add(TB);
    }

    public void Formato(Label L, string tipo)
    {
        L.Left = 12;
        L.ForeColor = System.Drawing.Color.Black;
        L.Font = new Font(nomFuente, 15);

        if (tipo == "e")
        {
            L.Top = 10;
            L.Width = 200;
        }
        if (tipo == "m")
        {
            L.Top = 75;
            L.Width = 200;
        }
        if (tipo == "k")
        {
            L.Top = 75;
            L.Left += 300;
            L.Width = 120;
        }
        if (tipo == "ej")
        {
            L.Top = 145;
            L.Width = 200;
        }
        if (tipo == "expl")
        {
            L.Top = 265;
            L.Width = 240;
        }
        this.Controls.Add(L);
    }
}


public class AreaDeEstudio : Form
{

    string[] palabra;
    string todoTexto;
    string respuesta = "";
    string respuestaEsperada = "";
    int modo = 0;
    int puntos = 5;
    string cModo = "O";
    int numVeces;
    string OracionEstudio = "";
    string nomFuente;
    string directorioVoc;
    Color colorFondo;
    Color colorLetra;
    Color colorBotones;
    TextBox TBRespuesta;
    Button BModo;
    Button BPista;
    Button BSiguiente;
    Button BModoOscuro;
    Label LOraciones;
    Label LMarco;
    bool modoOscuro;
    Herr her;

    public AreaDeEstudio(string nomFuente, string directorioVoc, bool modoOscuro)
    {
        this.modoOscuro = modoOscuro;
        this.Icon = new Icon("obento.ico");
        colorFondo = System.Drawing.Color.LightGray;
        colorBotones = System.Drawing.Color.WhiteSmoke;
        colorLetra = System.Drawing.Color.Black;

        this.nomFuente = nomFuente;
        this.directorioVoc = directorioVoc;
        her = new Herr();
        //this.WindowState = FormWindowState.Maximized;
        this.Width = 1080;
        this.Height = 600;

        this.Resize += CambioTamaño;
        this.DoubleBuffered = true;

        BModo = new Button();
        TBRespuesta = new TextBox();
        LOraciones = new Label();
        BSiguiente = new Button();
        LMarco = new Label();

       
        BModo.BackColor = System.Drawing.Color.LightGray;
        BModo.ForeColor = System.Drawing.Color.Black;
        BModo.Click += BModo_Click;
        this.Controls.Add(BModo);

        TBRespuesta.Text = "";
        TBRespuesta.Font = new Font(nomFuente, 35);
        //TBRespuesta.FlatStyle = FlatStyle.Flat;
        //TBRespuesta.Bord = 0;
        TBRespuesta.TextChanged += TBRespuesta_TextoCambio;
        TBRespuesta.KeyDown += TBRespuesta_BotonPresionado;
        this.Controls.Add(TBRespuesta);

        LOraciones.Font = new Font(nomFuente, 40);
        
        //LOraciones.BackColor = System.Drawing.Color.CornflowerBlue;
        this.Controls.Add(LOraciones);

        BPista = new Button();
        

        BPista.Click += BPista_Click;
        this.Controls.Add(BPista);

        BSiguiente.BackColor = System.Drawing.Color.LightGray;
        BSiguiente.ForeColor = System.Drawing.Color.Black;
        BSiguiente.Click += BSiguiente_Click;
        this.Controls.Add(BSiguiente);

        BModoOscuro = new Button();
        BModoOscuro.BackColor = System.Drawing.Color.LightGray;
        BModoOscuro.ForeColor = System.Drawing.Color.Black;
        BModoOscuro.Click += BModoOscuro_Click;
        this.Controls.Add(BModoOscuro);

        this.Controls.Add(LMarco);

        if (File.Exists("lingua.txt"))
        {
            this.Text = her.ExtraerTraduccion(16);
            BModoOscuro.Text = her.ExtraerTraduccion(17);
            BSiguiente.Text = her.ExtraerTraduccion(18);
            BPista.Text = her.ExtraerTraduccion(19);
            LOraciones.Text = her.ExtraerTraduccion(20);
            BModo.Text = her.ExtraerTraduccion(21);

        }
        else
        {
            BModoOscuro.Text = "Modo Oscuro";
            BSiguiente.Text = "Siguiente";
            BPista.Text = "Mostrar Respuesta";
            LOraciones.Text = "Muy buenas noches";
            BModo.Text = "Cambiar modo estudio";
            this.Text = "Área de estudio";
        }


        Formato();
        ActualizarPalabra();
    }
    void BPista_Click(object sender, EventArgs e)
    {
        TBRespuesta.Text = respuestaEsperada;
        TBRespuesta.BackColor = System.Drawing.Color.MediumPurple;
        puntos = 5;
    }

    void BModoOscuro_Click(object sender, EventArgs e)
    {

        if (modoOscuro)
        {
            her.CambiaArchivoConf("conf.txt", 2, "0");
            modoOscuro = false;

        }
        else
        {
            her.CambiaArchivoConf("conf.txt", 2, "1");
            modoOscuro = true;
        }


        Formato();
    }

    bool ActualizarPalabra()
    {
        palabra = her.PalabraMenosEstudiada(directorioVoc);
        Random rand = new Random();

        switch (modo)
        {
            case 0: //Modo Oracioón ______ palabra faltante
                respuestaEsperada = palabra[0];
                cModo = "O";
                break;
            case 1: //Modo lectura Kanji
                cModo = "F";
                //Console.WriteLine(palabra[0]);
                respuestaEsperada = her.ExtraerTexto(her.ImportarTexto(directorioVoc + "/" + palabra[0] + ".txt"), cModo);
                //Console.WriteLine(respuestaEsperada);
                break;
            case 2://Modo leer explicación
                cModo = "E";
                respuestaEsperada = palabra[0];
                break;
            case 3://Modo leer en lengua materna
                cModo = "M";
                respuestaEsperada = palabra[0];
                break;
        }

        todoTexto = her.ImportarTexto(directorioVoc + "/" + palabra[0] + ".txt");
        string OracionEstudio = "";


        if (modo == 0)
        {
            OracionEstudio = her.ExtraerTexto(todoTexto, cModo);
            OracionEstudio = OracionEstudio.Replace(palabra[0], "_____");
            BModo.Text = "Rellenar ___";
            puntos = 5 + rand.Next(0,5);

        }
        if (modo == 1)
        {
            OracionEstudio = palabra[0];
            BModo.Text = "Fonética";
            puntos = 5 + rand.Next(0, 5);

        }
        if (modo == 2)
        {
            OracionEstudio = her.ExtraerTexto(todoTexto, cModo);
            BModo.Text = "Explicación";
            puntos = 5 + rand.Next(0, 5);

        }
        if (modo == 3)
        {
            OracionEstudio = her.ExtraerTexto(todoTexto, cModo);
            BModo.Text = "Traducción";
            puntos = 5 + rand.Next(0, 5);
        }

        if (File.Exists("lingua.txt"))
        {
            string[] traducciones = File.ReadAllLines("lingua.txt", System.Text.Encoding.UTF8);

            BModo.Text = traducciones[22+modo];
        }
        LOraciones.Text = OracionEstudio;
        return true;
    }

    void CambioTamaño(object sender, EventArgs e)
    {
        //Console.WriteLine("Cambio de tamaño");
        Formato();
    }
    void Formato()
    {

        if (modoOscuro)
        {
            colorFondo = System.Drawing.Color.FromArgb(255, 0, 31, 51);
            colorLetra = System.Drawing.Color.WhiteSmoke;
            colorBotones = System.Drawing.Color.FromArgb(255, 0, 26, 51);

        }
        else
        {
            colorFondo = System.Drawing.Color.LightGray;
            colorLetra = System.Drawing.Color.Black;
            colorBotones = System.Drawing.Color.WhiteSmoke;
        }

        Color color = new Color();
        switch (modo)
        {
            case 0:
                if (modoOscuro)
                {
                    color = System.Drawing.Color.Brown;
                }
                else
                {
                    color = System.Drawing.Color.LightCoral;
                }

                break;
            case 1:

                if (modoOscuro)
                {
                    color = System.Drawing.Color.CornflowerBlue;
                }
                else
                {
                    color = System.Drawing.Color.CornflowerBlue;
                }

                break;
            case 2:

                if (modoOscuro)
                {
                    color = System.Drawing.Color.DarkOrange;
                }

                else
                {
                    color = System.Drawing.Color.Orange;
                }
                break;
            case 3:

                if (modoOscuro)
                {
                    color = System.Drawing.Color.LightGreen;
                }
                else
                {
                    color = System.Drawing.Color.LightGreen;
                }
                break;
        }


        BModoOscuro.FlatStyle = FlatStyle.Flat;
        BModoOscuro.FlatAppearance.BorderSize = 2;
        BModoOscuro.FlatAppearance.BorderColor = color;

        BSiguiente.FlatStyle = FlatStyle.Flat;
        BSiguiente.FlatAppearance.BorderSize = 2;
        BSiguiente.FlatAppearance.BorderColor = color;

        BModo.FlatStyle = FlatStyle.Flat;
        BModo.FlatAppearance.BorderSize = 2;
        BModo.FlatAppearance.BorderColor = color;

        BPista.FlatStyle = FlatStyle.Flat;
        BPista.FlatAppearance.BorderSize = 2;
        BPista.FlatAppearance.BorderColor = color;

        this.BackColor = colorFondo;

        LMarco.Height = this.Height / 2 + 40;
        LMarco.Width = 10 * this.Width / 12 + 40;
        LMarco.Left = this.Width / 12 - 20;
        LMarco.Top = 20;
        LMarco.AutoSize = false;
        LMarco.BackColor = color;

        LOraciones.Height = this.Height / 2;
        LOraciones.Width = 10 * this.Width / 12; ;
        LOraciones.Left = this.Width / 12;
        LOraciones.Top = 40;
        LOraciones.AutoSize = false;
        LOraciones.BackColor = colorBotones;
        LOraciones.ForeColor = colorLetra;
        LOraciones.TextAlign = ContentAlignment.MiddleCenter;

        TBRespuesta.Height = this.Height / 8;
        TBRespuesta.Width = this.Width / 3;
        TBRespuesta.Left = this.Width / 3;
        TBRespuesta.Top = 2 * this.Height / 3;
        TBRespuesta.TextAlign = HorizontalAlignment.Center;

        BModo.Height = this.Height / 12;
        BModo.Width = this.Width / 9;
        BModo.Left = this.Width / 3;
        BModo.Top = this.Height* 19/24;
        BModo.BackColor = colorBotones;
        BModo.ForeColor = colorLetra;

        BSiguiente.Height = this.Height / 12;
        BSiguiente.Width = this.Width / 9;
        BSiguiente.Left =  + this.Width / 3+ this.Width / 9; ;
        BSiguiente.Top = this.Height * 19 / 24;
        BSiguiente.BackColor = colorBotones;
        BSiguiente.ForeColor = colorLetra;

        BModoOscuro.Height = this.Height / 24;
        BModoOscuro.Width = this.Width / 9;
        BModoOscuro.Left = +this.Width / 3 + this.Width / 9; ;
        BModoOscuro.Top = this.Height * 21 / 24 + 5;
        BModoOscuro.BackColor = colorBotones;
        BModoOscuro.ForeColor = colorLetra;

        BPista.Height = this.Height / 12;
        BPista.Width = this.Width / 9;
        BPista.Left = this.Width / 3 + this.Width* 2/ 9; ;
        BPista.Top = this.Height * 19 / 24;
        BPista.BackColor = colorBotones;
        BPista.ForeColor = colorLetra;

        TBRespuesta.Select();
        this.Refresh();
    }

    void TBRespuesta_BotonPresionado(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            BSiguiente_Click(this, new EventArgs());
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
    }

    void TBRespuesta_TextoCambio(object sender, EventArgs e)
    {
        respuesta = TBRespuesta.Text;
        if (respuesta == respuestaEsperada)
        {
            TBRespuesta.BackColor = System.Drawing.Color.LightGreen;
        }
        else
        {
            TBRespuesta.BackColor = System.Drawing.Color.White;
        }
    }

    bool RevisarRespuesta()
    {
        numVeces = Int32.Parse(palabra[1]);
        if (respuesta == "")
        {
            string texto = Regex.Replace("\n" + File.ReadAllText(directorioVoc + "/00.txt"), "\n" + palabra[0] + ":" + numVeces, "\n" + palabra[0] + ":" + (numVeces + 10));
            texto = texto.Substring(1);
            File.WriteAllText(directorioVoc + "/00.txt", texto);
            return true;
        }
        if (respuesta == respuestaEsperada)
        {
            string texto = Regex.Replace("\n" + File.ReadAllText(directorioVoc + "/00.txt"), "\n" + palabra[0] + ":" + numVeces, "\n" + palabra[0] + ":" + (numVeces + puntos));
            texto = texto.Substring(1);
            File.WriteAllText(directorioVoc + "/00.txt", texto);

            //Console.Beep(440, 200);
            //Console.Beep(37, 50);
            //Console.Beep(600, 300);

            return true;
        }
        else
        {
            if(TBRespuesta.BackColor == System.Drawing.Color.FromArgb(255, 255, 51, 51))
            {
                return true;
            }
            //Console.Beep(440, 200);
            //Console.Beep(440, 200);
            return false;
        }



        
    }

    void BModo_Click(object sender, EventArgs e)
    {
        if (modo == 0)
        {
            modo++;
        }
        else if (modo == 1)
        {
            modo++;
        }
        else if (modo == 2)
        {
            modo++;
        }
        else if (modo == 3)
        {
            modo = 0;
        }
        ActualizarPalabra();
        Formato();
        this.Refresh();
    }

    void BSiguiente_Click(object sender, EventArgs e)
    {
        if (!RevisarRespuesta()) {
            TBRespuesta.BackColor = System.Drawing.Color.FromArgb(255, 255, 51, 51);
        }
        else
        {
            ActualizarPalabra();
            TBRespuesta.Select();
            TBRespuesta.Text = "";
        }

    }
}

public class Herr
{
    public void CambiaArchivoConf(string dir, int linea, string entrada)
    {
        string[] textoConfigCompleto = File.ReadAllLines(dir);
        textoConfigCompleto[linea] = entrada;
        File.WriteAllLines(dir, textoConfigCompleto);
    }
    public string ImportarTexto(string archivo)
    {
        string texto = File.ReadAllText(archivo);
        return texto;
    }
    public string[] ExtraerPalabraMenosEst(string todoTexto)
    {
        char bandera = '\n';
        string[] arrTexto = todoTexto.Split(bandera);
        string[] texto = new string[arrTexto.Length];
        int[] numero = new int[arrTexto.Length];
        //Console.WriteLine("Num Palabras:"+(arrTexto.Length-1));

        for (int i = 0; i < arrTexto.Length; i++)
        {
            int nDosPunts = arrTexto[i].IndexOf(":");
            texto[i] = arrTexto[i].Substring(0, nDosPunts);
            //Console.WriteLine(i+":"+texto[i]);
            numero[i] = Int32.Parse(arrTexto[i].Substring(nDosPunts + 1));
            //Console.WriteLine(i+":"+numero[i]);
        }
        //Console.WriteLine("último:"+texto[arrTexto.Length-2]+","+numero[arrTexto.Length-2]);
        string[] temp = { texto[IndexOfMin(numero)], "" + numero[IndexOfMin(numero)] };
        //Console.WriteLine("Regreso:"+temp[0]+","+temp[1]);
        return temp;
    }
    public string ExtraerTexto(string todoTexto, string bandera)
    {
        string[] banderas = { "[" + bandera + "]", "[/" + bandera + "]" };
        string[] arrTexto = todoTexto.Split(banderas, System.StringSplitOptions.RemoveEmptyEntries);
        if (bandera == "N")
        {
            return arrTexto[0];
        }
        else
        {
            return arrTexto[1];
        }
    }
    public string[] PalabraMenosEstudiada(string directorioVoc)
    {
        string[] textoNumero = new string[2];
        textoNumero = ExtraerPalabraMenosEst(ImportarTexto(directorioVoc + "/00.txt"));
        //Console.WriteLine("Texto y número recibidos");
        return textoNumero;

    }

    public string ExtraerTraduccion(int linea)
    {
        string textoTraduccion = ImportarTexto("lingua.txt");
        string[] arrTexto = textoTraduccion.Split('\n');
        return arrTexto[linea];
    }
    public static int IndexOfMin(int[] source)
    {
        if (source == null)
            throw new ArgumentNullException("source");

        int minValue = int.MaxValue;
        int minIndex = -1;
        int index = -1;

        foreach (int num in source)
        {
            index++;

            if (num <= minValue)
            {
                minValue = num;
                minIndex = index;
            }
        }

        if (index == -1)
            throw new InvalidOperationException("Sequence was empty");

        return minIndex;
    }
}

