using System;
using System.Windows.Forms;
using System.Windows;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Text.RegularExpressions;

public class PanelControl : Form
{
  static public void Main ()
  {
    Application.EnableVisualStyles();
    Application.Run (new PanelControl ());
  }

  ListBox LBDirectorio;
  TextBox TBNuevoDir;
  string nomFuente = "TakaoMincho";
  int tamFuente = 12;
  string directorioVoc = "";
  string textoNuevoDir = "";
  string[] archivos = {};
  ComboBox CBFuentes;
  Herr her;

  public PanelControl ()
  {
    Herr her = new Herr();
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    Button BEstudio = new Button();
    Button BGuardar = new Button();
    LBDirectorio = new ListBox();
    Label LElija = new Label();
    Button BAgregarDir = new Button();
    TBNuevoDir = new TextBox();

    this.Controls.Add(TBNuevoDir);
    this.Controls.Add(BEstudio);
    this.Controls.Add(LElija);
    this.Controls.Add(LBDirectorio);
    this.Controls.Add(BGuardar);
    this.Controls.Add(BAgregarDir);

    //Herr her = new Herr();
    this.Width = 500;
    this.Height = 400;
    this.Text = "Obento~";
    this.BackColor = System.Drawing.Color.LightGray;
    string SBGuardar = "Guardar";

    LElija.Left = 10;
    LElija.Top = 20;
    LElija.ForeColor = System.Drawing.Color.Black;
    LElija.Width = 400;
    LElija.Height = 30;
    LElija.Text = "Elija el directorio:";

    Label LAgregar = new Label();
    LAgregar.Left = 10;
    LAgregar.Top = 230;
    LAgregar.Width = 400;
    LAgregar.Height = 30;
    LAgregar.ForeColor = System.Drawing.Color.Black;
    this.Controls.Add(LAgregar);
    LAgregar.Text = "Agregar directorio (sin 'voc/'):";

    Label LFuente = new Label();
    LFuente.Left = 10;
    LFuente.Top = 300;
    LFuente.Width = 100;
    LFuente.Height = 20;
    LFuente.ForeColor = System.Drawing.Color.Black;
    LFuente.Text = "Fuente:";
    this.Controls.Add(LFuente);

    CBFuentes = new ComboBox();
    CBFuentes.Left = 10;
    CBFuentes.Top = 320;
    //CBFuentes.AllowDrop = true;
    CBFuentes.SelectedIndexChanged += CBFuentes_Cambio;
    this.Controls.Add(CBFuentes);

    if(Directory.Exists("voc/")){
      archivos = Directory.GetDirectories("voc");
    }
    else{
      Directory.CreateDirectory("voc");
      this.Refresh();
    }

    InstalledFontCollection fontCol = new InstalledFontCollection();
    for (int x = 0; x <= fontCol.Families.Length-1;x++ )
    {
      CBFuentes.Items.Add(fontCol.Families[x].Name);
    }

    //LBDirectorio.AllowDrop = true;
    LBDirectorio.DataSource = archivos;
    LBDirectorio.Left = 10;
    LBDirectorio.Top = 50;
    LBDirectorio.Width = 300;
    LBDirectorio.Height = 160;
    LBDirectorio.HorizontalScrollbar = true;
    LBDirectorio.SelectedValueChanged += LBDirectorio_CambioDirectorio;
    LBDirectorio.ForeColor = System.Drawing.Color.Black;

    TBNuevoDir.Width = 300;
    TBNuevoDir.Height = 30;
    TBNuevoDir.Left = 10;
    TBNuevoDir.Top = 250;
    //TBNuevoDir.TextChanged += TBNuevoDir_CambioTexto;

    BGuardar.Width = 100;
    BGuardar.Left = 350;
    BGuardar.Top = 50;
    BGuardar.Text = SBGuardar;
    BGuardar.UseCompatibleTextRendering = true;
    BGuardar.Click +=  BGuardar_Click;
    BGuardar.BackColor = System.Drawing.Color.Gray;
    BGuardar.ForeColor = System.Drawing.Color.White;

    BAgregarDir.Width = 100;
    BAgregarDir.Left = 350;
    BAgregarDir.Top = 250;
    BAgregarDir.Text = "Agregar";
    BAgregarDir.UseCompatibleTextRendering = true;
    BAgregarDir.Click +=  BAgregarDir_Click;
    BAgregarDir.BackColor = System.Drawing.Color.Gray;
    BAgregarDir.ForeColor = System.Drawing.Color.White;

    BEstudio.Width = 100;
    BEstudio.Left = 350;
    BEstudio.Top = 75;
    BEstudio.Text = "Estudiar";
    BEstudio.UseCompatibleTextRendering = true;

    BEstudio.Click +=  BEstudio_Click;
    BEstudio.BackColor = System.Drawing.Color.Gray;
    BEstudio.ForeColor = System.Drawing.Color.White;
    directorioVoc = LBDirectorio.SelectedValue.ToString();

    LElija.Font = new Font(nomFuente, tamFuente + 3);
    LAgregar.Font = new Font(nomFuente, tamFuente);
    LFuente.Font = new Font(nomFuente, tamFuente);
    BGuardar.Font = new Font(nomFuente, tamFuente);
    BAgregarDir.Font = new Font(nomFuente, tamFuente);
    BEstudio.Font = new Font(nomFuente, tamFuente);

    Button BBorrarInfo = new Button();
    BBorrarInfo.Left = 350;
    BBorrarInfo.Top = 150;
    BBorrarInfo.Text = "Reiniciar";
    BBorrarInfo.Click += BBorrarInfo_Click;
    this.Controls.Add(BBorrarInfo);
    //nomFuente = CBFuentes.SelectedItem.ToString();
  }

  void BBorrarInfo_Click(object sender, EventArgs e){

    string texto = File.ReadAllText(directorioVoc+"/lista.txt");
    char bandera ='\n';
    Console.WriteLine(texto);
    File.WriteAllText(directorioVoc+"/lista.txt","");
    string[] arrTexto = texto.Split(bandera);
    texto = "";
    string s = "";

    for(int i = 0;i <arrTexto.Length-1; i++){
      //Console.WriteLine("Entró a for");
      s = arrTexto[i];
      int iDosP = s.IndexOf(":");
      string numVeces = s.Substring(iDosP+1, s.Length - iDosP - 1);
      s = s.Replace(numVeces, "0");
      if(i==0){
        texto += s;
      }
      if(i>0){
        texto+= "\n"+s;
      }
      //Console.Write(texto);
    }
    File.WriteAllText(directorioVoc+"/lista.txt", texto);
    MessageBox.Show("Se ha reiniciado la cuenta de estudio de "+directorioVoc);
  }

  void CBFuentes_Cambio(object sender, EventArgs e){
      nomFuente = CBFuentes.SelectedItem.ToString();
      this.Refresh();

  }


  void BEstudio_Click(object sender, EventArgs e)
  {
    //directorioVoc = "voc/"+(string)(LBDirectorio.SelectedText);

    if(File.ReadAllText(directorioVoc+"/lista.txt") != ""){
      //Console.WriteLine("Sí hay palabras");
      AreaDeEstudio AdE = new AreaDeEstudio(nomFuente, directorioVoc);
      AdE.Show();
    }
    else{
      MessageBox.Show("No hay palabras a estudiar, agruegue palabras primero.");
    }
  }

  void BAgregarDir_Click(object sender, EventArgs e)
  {
    if(TBNuevoDir.Text != ""){
      Directory.CreateDirectory("voc/"+TBNuevoDir.Text);
      //File.Create("voc/"+TBNuevoDir.Text+"/lista.txt");
      File.WriteAllText("voc/"+TBNuevoDir.Text+"/lista.txt","");
      TBNuevoDir.Text = "";
      archivos = Directory.GetDirectories("voc");
      LBDirectorio.DataSource = archivos;
      this.Refresh();
      //this.Update();
    }
  }

  void BGuardar_Click(object sender, EventArgs e)
  {
    directorioVoc = LBDirectorio.SelectedValue.ToString();
    RegistroDiccionario RD = new RegistroDiccionario(nomFuente, directorioVoc);
    RD.Show();
  }

  void LBDirectorio_CambioDirectorio(object sender, EventArgs e){
    directorioVoc = LBDirectorio.SelectedValue.ToString();
    //Console.WriteLine("Directorio:"+directorioVoc);
  }

}

public class RegistroDiccionario : Form
{
  string nomFuente;
  string directorioVoc;
  TextBox TBEntradaEstudio,TBExplicacion,TBFonetico, TBEntradaMaterna, TBOracionEjemplo;
  Herr her;
  Form FSobreE;

  string archivo;

  public RegistroDiccionario(string nomFuente, string directorioVoc)
  {
    this.FormBorderStyle = FormBorderStyle.FixedSingle;
    this.nomFuente = nomFuente;
    this.directorioVoc = directorioVoc;
    her = new Herr();
    BackColor = System.Drawing.Color.LightGray;
    Width = 530;
    Height = 600;

    Label LNuevaPalabra = new Label();
    Formato(LNuevaPalabra, "e");
    TBEntradaEstudio = new TextBox();
    Formato(TBEntradaEstudio, "e");

    Label LTradLiteral = new Label();
    Formato(LTradLiteral, "m");
    TBEntradaMaterna = new TextBox();
    Formato(TBEntradaMaterna, "m");

    Label LFonetica = new Label();
    Formato(LFonetica, "k");
    TBFonetico = new TextBox();
    Formato(TBFonetico, "k");

    Label LEjemplo = new Label();
    Formato(LEjemplo, "ej");
    TBOracionEjemplo = new TextBox();
    Formato(TBOracionEjemplo,"ej");

    Label LExplicacion = new Label();
    Formato(LExplicacion, "expl");
    TBExplicacion = new TextBox();
    Formato(TBExplicacion, "expl");

    Button BGuardar = new Button();
    BGuardar.Width = 120;
    BGuardar.Left = 380;
    BGuardar.Top = 520;
    BGuardar.Text = "Guardar";
    BGuardar.UseCompatibleTextRendering = true;
    this.Controls.Add(BGuardar);
    BGuardar.Font = new Font(nomFuente, 12);
    BGuardar.Click +=  BGuardar_Click;
    BGuardar.BackColor = System.Drawing.Color.Gray;
    BGuardar.ForeColor = System.Drawing.Color.White;

    Button BEditarEntrada = new Button();
    BEditarEntrada.Width = 120;
    BEditarEntrada.Left = 220;
    BEditarEntrada.Top = 520;
    BEditarEntrada.Text = "Editar";
    BEditarEntrada.UseCompatibleTextRendering = true;
    this.Controls.Add(BEditarEntrada);
    BEditarEntrada.Font = new Font(nomFuente, 12);
    BEditarEntrada.Click +=  BEditarEntrada_Click;
    BEditarEntrada.BackColor = System.Drawing.Color.Gray;
    BEditarEntrada.ForeColor = System.Drawing.Color.White;
  }

  void BEditarEntrada_Click(object sender, EventArgs e){
    archivo = directorioVoc+"/"+TBEntradaEstudio.Text+".txt";

    if (File.Exists(archivo)){
      LlenarRegistro(archivo);
    }
  }

  void BGuardar_Click(object sender, EventArgs e)
  {
    archivo = directorioVoc+"/"+TBEntradaEstudio.Text+".txt";
    if (!File.Exists(archivo))
    {
      FileStream fs = File.Create(archivo);
      //File.Dispose();
      if(TBFonetico.Text == ""){
        TBFonetico.Text ="-";
      }
      if(TBExplicacion.Text == ""){
        TBFonetico.Text ="-";
      }
      if(TBEntradaMaterna.Text == ""){
        TBEntradaMaterna.Text ="-";
      }
      if(TBOracionEjemplo.Text == ""){
        TBOracionEjemplo.Text ="-";
      }

      string texto =  "[N]0[/N]\n"
      +  "[V]"+TBEntradaEstudio.Text + "[/V]\n"
      +  "[M]"+TBEntradaMaterna.Text + "[/M]\n"
      +  "[F]"+TBFonetico.Text + "[/F]\n"
      +  "[O]"+TBOracionEjemplo.Text +"[/O]\n"
      +  "[E]"+TBExplicacion.Text +"[/E]\n";
      fs.Dispose();

      StreamWriter SW = new StreamWriter(archivo);
      SW.Write(texto);
      SW.Dispose();

      string entrada;
      if(File.ReadAllText(directorioVoc+"/lista.txt") == ""){
        entrada = TBEntradaEstudio.Text+":0";
      }
      else{
        entrada = TBEntradaEstudio.Text+":0";
      }

      SW = File.AppendText(directorioVoc+"/lista.txt");
      //Console.WriteLine("Se escribió en lista"+entrada);
      SW.WriteLine(entrada);

      SW.Dispose();

      TBEntradaEstudio.Text = "";
      TBEntradaMaterna.Text = "";
      TBExplicacion.Text = "";
      TBOracionEjemplo.Text = "";
      TBFonetico.Text = "";

    }
    else if (File.Exists(archivo)){

      FSobreE = new Form();

      Button BSobreE = new Button();
      BSobreE.Text = "Sobreescribir";
      BSobreE.BackColor = System.Drawing.Color.LightGray;
      BSobreE.ForeColor = System.Drawing.Color.Black;
      BSobreE.Height = 30;
      BSobreE.Width = 120;
      BSobreE.Left = 40;
      BSobreE.Top = 30;
      BSobreE.Click +=  BSobreE_Click;

      Button BEditar = new Button();
      BEditar.Text = "Editar";
      BEditar.BackColor = System.Drawing.Color.LightGray;
      BEditar.ForeColor = System.Drawing.Color.Black;
      BEditar.Height = 30;
      BEditar.Width = 120;
      BEditar.Left = 40;
      BEditar.Top = 100;
      BEditar.Click +=  BEditar_Click;
      //BEditar.FlatStyle = FlatStyle.System;

      FSobreE.Width = 200;
      FSobreE.Height = 220;
      FSobreE.Show();

      FSobreE.Controls.Add(BSobreE);
      FSobreE.Controls.Add(BEditar);
    }
  }
    void BSobreE_Click(object sender, EventArgs e)
    {
      File.Delete(archivo);
      FileStream fs = File.Create(archivo);

      if(TBFonetico.Text == ""){
        TBFonetico.Text ="-";
      }

      string texto =  "[N]0[/N]\n"
      +  "[V]"+TBEntradaEstudio.Text + "[/V]\n"
      +  "[M]"+TBEntradaMaterna.Text + "[/M]\n"
      +  "[F]"+TBFonetico.Text + "[/F]\n"
      +  "[O]"+TBOracionEjemplo.Text +"[/O]\n"
      +  "[E]"+TBExplicacion.Text +"[/E]\n";
      fs.Dispose();

      StreamWriter SW = new StreamWriter(archivo);
      SW.Write(texto);
      SW.Dispose();

      string entrada = "";

      if(!File.Exists(directorioVoc+"/lista.txt")){
        File.WriteAllText(directorioVoc+"/lista.txt","");
      }

      if(File.ReadAllText(directorioVoc+"/lista.txt").Contains(TBEntradaEstudio.Text)){
        //entrada = TBEntradaEstudio.Text+":0";
      }
      else
      {
        entrada = TBEntradaEstudio.Text+":0";
        SW = File.AppendText(directorioVoc+"/lista.txt");
        SW.WriteLine(entrada);
        SW.Dispose();
      }

      TBEntradaEstudio.Text = "";
      TBEntradaMaterna.Text = "";
      TBExplicacion.Text = "";
      TBOracionEjemplo.Text = "";
      TBFonetico.Text = "";

      FSobreE.Dispose();
    }

    void BEditar_Click(object sender, EventArgs e){
      FSobreE.Dispose();
      LlenarRegistro(archivo);
    }

    public void LlenarRegistro(string archivo){
      Herr her = new Herr();
      string todoTexto = her.ImportarTexto(archivo);
      RegistroDiccionario RD = new RegistroDiccionario(nomFuente, directorioVoc);
      RD.Controls[1].Text = her.ExtraerTexto(todoTexto, "V");
      RD.Controls[3].Text = her.ExtraerTexto(todoTexto, "M");
      RD.Controls[5].Text = her.ExtraerTexto(todoTexto, "F");
      RD.Controls[7].Text = her.ExtraerTexto(todoTexto, "O");
      RD.Controls[9].Text = her.ExtraerTexto(todoTexto, "E");

      RD.Show();
    }

    public void Formato(TextBox TB, string tipo)
    {
      TB.Left = 12;
      TB.Font = new Font(nomFuente,20);
      //TB.FlatStyle = FlatStyle.Flat;

      if(tipo == "e"){
        TB.Top = 35;
        TB.Width = 240;
      }
      if(tipo == "m"){
        TB.Top = 100;
        TB.Width = 240;
      }
      if(tipo == "k"){
        TB.Top = 100;
        TB.Left += 300;
        TB.Width = 200;
      }
      if(tipo == "ej"){
        TB.Multiline = true;
        TB.Top = 170;
        TB.Height = 90;
        TB.Width = 500;
      }
      if(tipo == "expl"){
        TB.Multiline = true;
        TB.Top = 290;
        TB.Height = 220;
        TB.Width = 500;
      }
      this.Controls.Add(TB);
    }

    public void Formato(Label L, string tipo)
    {
      L.Left = 12;
      L.ForeColor = System.Drawing.Color.Black;
      L.Font = new Font(nomFuente,15);

      if(tipo == "e"){
        L.Top = 10;
        L.Width = 200;
        L.Text = "Nueva palabra:";
      }
      if(tipo == "m"){
        L.Top = 75;
        L.Width = 200;
        L.Text = "Traducción literal:";
      }
      if(tipo == "k"){
        L.Top = 75;
        L.Left += 300;
        L.Width = 120;
        L.Text = "Fonética:";
      }
      if(tipo == "ej"){
        L.Top = 145;
        L.Width = 200;
        L.Text = "Oraciones ejemplo:";
      }
      if(tipo == "expl"){
        L.Top = 265;
        L.Width = 240;
        L.Text = "Explicación adicional:";
      }
      this.Controls.Add(L);
    }
  }


public class AreaDeEstudio : Form{

  string[] palabra;
  string todoTexto;
  string respuesta = "";
  string respuestaEsperada = "";
  int modo = 0  ;
  int puntos = 20;
  string cModo = "O";
  int numVeces;
  string OracionEstudio = "";
  string nomFuente;
  string directorioVoc;
  TextBox TBRespuesta;
  Button BModo;
  Label LOraciones;
  Herr her;

  public AreaDeEstudio(string nomFuente, string directorioVoc){

    this.nomFuente = nomFuente;
    this.directorioVoc = directorioVoc;
    her = new Herr();
    //this.WindowState = FormWindowState.Maximized;
    this.Width = 1080;
    this.Height = 600;

    this.Resize += CambioTamaño;
    this.DoubleBuffered = true;

    BModo = new Button();
    TBRespuesta = new TextBox();
    LOraciones = new Label();
    Button BSiguiente = new Button();
    BModo.Text = "Cambiar modo estudio";
    BModo.Font = new Font(nomFuente,10);
    BModo.BackColor = System.Drawing.Color.LightGray;
    BModo.ForeColor = System.Drawing.Color.Black;
    BModo.Height = 50;
    BModo.Width = 120;
    BModo.Left = 40;
    BModo.Top = 450;
    BModo.Click += BModo_Click;
    this.Controls.Add(BModo);

    TBRespuesta.Text = "";
    TBRespuesta.Font = new Font(nomFuente,35);
    TBRespuesta.Height = 50;
    TBRespuesta.Width = this.Width/3;
    TBRespuesta.Left = this.Width/3;
    TBRespuesta.Top = 2*this.Height/3 + 50;
    TBRespuesta.TextChanged += TBRespuesta_TextoCambio;
    TBRespuesta.KeyDown += TBRespuesta_BotonPresionado;
    TBRespuesta.TextAlign = HorizontalAlignment.Center;
    this.Controls.Add(TBRespuesta);

    LOraciones.Font = new Font(nomFuente,40);
    LOraciones.Height = this.Height/2;
    LOraciones.Width = 10*this.Width/12;;
    LOraciones.Left = this.Width/12;
    LOraciones.Top = 40;
    LOraciones.AutoSize = false;
    LOraciones.TextAlign = ContentAlignment.MiddleCenter;
    LOraciones.Text = "Muy buenas noches";
    //LOraciones.BackColor = System.Drawing.Color.CornflowerBlue;
    this.Controls.Add(LOraciones);

    Button BPista = new Button();
    BPista.Height = 30;
    BPista.Width = 120;
    BPista.Left = 600;
    BPista.Top = 400;
    BPista.Text = "Mostrar Respuesta";
    BPista.Click += BPista_Click;
    this.Controls.Add(BPista);

    BSiguiente.Text = "Siguiente";
    BSiguiente.BackColor = System.Drawing.Color.LightGray;
    BSiguiente.ForeColor = System.Drawing.Color.Black;
    BSiguiente.Height = 30;
    BSiguiente.Width = 120;
    BSiguiente.Left = 40;
    BSiguiente.Top = 400;
    BSiguiente.Click += BSiguiente_Click;
    this.Controls.Add(BSiguiente);

    ActualizarPalabra();
  }
    void BPista_Click(object sender, EventArgs e){
      TBRespuesta.Text = respuestaEsperada;
      TBRespuesta.BackColor = System.Drawing.Color.MediumOrchid;
      puntos = 5;
    }

    bool ActualizarPalabra(){
      palabra = her.PalabraMenosEstudiada(directorioVoc);

      switch(modo){
        case 0: //Modo Oracioón ______ palabra faltante
        respuestaEsperada = palabra[0];
        cModo = "O";
        break;
        case 1: //Modo lectura Kanji
        cModo = "F";
        //Console.WriteLine(palabra[0]);
        respuestaEsperada = her.ExtraerTexto(her.ImportarTexto(directorioVoc+"/"+palabra[0]+".txt"), cModo);
        //Console.WriteLine(respuestaEsperada);
        break;
        case 2://Modo leer explicación
        cModo = "E";
        respuestaEsperada = palabra[0];
        break;
        case 3://Modo leer en lengua materna
        cModo = "M";
        respuestaEsperada = palabra[0];
        break;
      }

      todoTexto = her.ImportarTexto(directorioVoc+"/"+palabra[0]+".txt");
      string OracionEstudio = "";

      if(modo == 0){
        OracionEstudio = her.ExtraerTexto(todoTexto, cModo);
        OracionEstudio = OracionEstudio.Replace(palabra[0], "_____");
        BModo.Text = "A___B";
        puntos = 15;

      }
      if(modo == 1){
        OracionEstudio = palabra[0];
        BModo.Text = "漢字言葉";
        puntos = 5;

      }
      if(modo == 2){
        OracionEstudio = her.ExtraerTexto(todoTexto, cModo);
        BModo.Text = "Explicación";
        puntos = 10;

      }
      if(modo == 3){
        OracionEstudio = her.ExtraerTexto(todoTexto, cModo);
        BModo.Text = "Traducción";
      }
      LOraciones.Text = OracionEstudio;
      return true;
    }

    void CambioTamaño(object sender, EventArgs e){

    }

    void TBRespuesta_BotonPresionado(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.Enter)
      {
        BSiguiente_Click(this, new EventArgs());
      }
    }

    void TBRespuesta_TextoCambio(object sender, EventArgs e){
      respuesta = TBRespuesta.Text;
      if(respuesta == respuestaEsperada){
        TBRespuesta.BackColor = System.Drawing.Color.LightGreen;
      }
      else{
        TBRespuesta.BackColor = System.Drawing.Color.White;
      }
    }

    bool RevisarRespuesta(){
      numVeces = Int32.Parse(palabra[1]);
      if(respuesta == ""){
        File.WriteAllText(directorioVoc+"/lista.txt", Regex.Replace(File.ReadAllText(directorioVoc+"/lista.txt"), palabra[0]+":"+numVeces, palabra[0]+":"+(numVeces+50)));

      }
      if(respuesta == respuestaEsperada){
        //Console.WriteLine("Se reemplazó:"+palabra[0]+":"+(numVeces+1));
        File.WriteAllText(directorioVoc+"/lista.txt", Regex.Replace(File.ReadAllText(directorioVoc+"/lista.txt"), palabra[0]+":"+numVeces, palabra[0]+":"+(numVeces+puntos)));
        return true;
      }
      else{
        return false;
      }
    }

    void BModo_Click(object sender, EventArgs e){
      if(modo == 0){
        modo++;
        puntos = 15;
      }
      else if(modo == 1){
        modo++;
        puntos = 5;
      }
      else if(modo == 2){
        modo ++;
        puntos = 10;
      }
      else if(modo == 3){
        modo = 0;
        puntos = 7;
      }
      ActualizarPalabra();
      this.Refresh();
    }

    void BSiguiente_Click(object sender, EventArgs e){
      RevisarRespuesta();
      ActualizarPalabra();
      TBRespuesta.Select();
      TBRespuesta.Text = "";
  }
}

public class Herr
{
  public string ImportarTexto(string archivo){
    string texto = File.ReadAllText(archivo);
    return texto;
  }
  public string[] ExtraerPalabraMenosEst(string todoTexto){
    char bandera ='\n';
    string[] arrTexto = todoTexto.Split(bandera);
    string[] texto = new string[arrTexto.Length-1];
    int[] numero = new int[arrTexto.Length-1];
    //Console.WriteLine("Num Palabras:"+(arrTexto.Length-1));

    for(int i = 0; i < arrTexto.Length-1; i++){
      int nDosPunts = arrTexto[i].IndexOf(":");
      texto[i] = arrTexto[i].Substring(0,nDosPunts);
      //Console.WriteLine(i+":"+texto[i]);
      numero[i] = Int32.Parse(arrTexto[i].Substring(nDosPunts+1));
      //Console.WriteLine(i+":"+numero[i]);
    }
    //Console.WriteLine("último:"+texto[arrTexto.Length-2]+","+numero[arrTexto.Length-2]);
    string[] temp = {texto[IndexOfMin(numero)],""+numero[IndexOfMin(numero)]};
    //Console.WriteLine("Regreso:"+temp[0]+","+temp[1]);
    return temp;
  }
  public string ExtraerTexto(string todoTexto, string bandera){
    string[] banderas = {"["+bandera+"]","[/"+bandera+"]"};
    string[] arrTexto = todoTexto.Split(banderas,System.StringSplitOptions.RemoveEmptyEntries);
    if(bandera == "N"){
      return arrTexto[0];
    }
    else{
      return arrTexto[1];
    }
  }
  public string[] PalabraMenosEstudiada(string directorioVoc){
    string[] textoNumero = new string[2];
    textoNumero = ExtraerPalabraMenosEst(ImportarTexto(directorioVoc+"/lista.txt"));
    //Console.WriteLine("Texto y número recibidos");
    return textoNumero;

  }
  public static int IndexOfMin(int[] source)
  {
    if(source == null)
    throw new ArgumentNullException("source");

    int minValue = int.MaxValue;
    int minIndex = -1;
    int index = -1;

    foreach(int num in source)
    {
      index++;

      if(num <= minValue)
      {
        minValue = num;
        minIndex = index;
      }
    }

    if(index == -1)
    throw new InvalidOperationException("Sequence was empty");

    return minIndex;
  }
}
