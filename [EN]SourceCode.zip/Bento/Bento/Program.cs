﻿using System;
using System.Windows.Forms;
using System.Windows;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Text.RegularExpressions;

public class PanelControl : Form
{
    static string fontName;
    static bool darkMode;
    static int dirNumber;
    static public void Main()
    {
        if (File.Exists("conf.txt"))
        {

            string[] config = File.ReadAllLines("conf.txt");
            if (config.Length == 3)
            {
                int totDirNumber;
                fontName = config[0];

                dirNumber = Int32.Parse(config[1]);

                if ("1" == config[2])
                {
                    darkMode = true;
                    Console.WriteLine("Starting in dark mode");
                }
                else
                {
                    darkMode = false;
                }

                if (Directory.Exists("voc/"))
                {
                    string[] fileArray = Directory.GetDirectories("voc");
                    totDirNumber = fileArray.Length;
                    if (dirNumber < totDirNumber)
                    {
                    }
                    else
                    {
                        dirNumber = -1;
                    }
                }
                else
                {
                    dirNumber = -1;
                }


            }
            else
            {
                MessageBox.Show("Config file reset");
                string[] text = { "TakaoMincho", "-1", "0" };
                File.WriteAllLines("conf.txt", text);
            }
        }
        else
        {
            MessageBox.Show("'conf.txt' has been generated");
            string[] text = { "TakaoMincho", "-1", "0" };
            File.WriteAllLines("conf.txt", text);
        }

        Application.EnableVisualStyles();
        Application.Run(new PanelControl(fontName, darkMode, dirNumber));
    }

    //All LB are labels
    //All B are buttons
    //All TB are textboxes
    //and so... CB -> ComboBox etc...

    ListBox LBDirectory;
    TextBox TBNewDirectory;

    int fontSize = 12;
    string vocDirectory = "";
    string newDirText = "";
    string[] fileArray = { };
    ComboBox CBFonts;
    Herr her = new Herr();

    public PanelControl(string fontName, bool darkMode, int dirNumber)
    {
        this.Icon = new Icon("obento.ico");
        MaximizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        Button BStudy = new Button();
        Button BSave = new Button();
        Button BUpdate = new Button();
        LBDirectory = new ListBox();
        Label LChoose = new Label();
        Button BAddDir = new Button();
        TBNewDirectory = new TextBox();

        this.Controls.Add(TBNewDirectory);
        this.Controls.Add(BStudy);
        this.Controls.Add(LChoose);
        this.Controls.Add(LBDirectory);
        this.Controls.Add(BSave);
        this.Controls.Add(BAddDir);
        this.Controls.Add(BUpdate);

        //Herr her = new Herr();
        this.Width = 500;
        this.Height = 400;
        this.Text = "Obento~";
        this.BackColor = System.Drawing.Color.LightGray;

        LChoose.Left = 10;
        LChoose.Top = 20;
        LChoose.ForeColor = System.Drawing.Color.Black;
        LChoose.Width = 400;
        LChoose.Height = 30;

        Label LAdd = new Label();
        LAdd.Left = 10;
        LAdd.Top = 230;
        LAdd.Width = 400;
        LAdd.Height = 30;
        LAdd.ForeColor = System.Drawing.Color.Black;
        this.Controls.Add(LAdd);

        Label LFont = new Label();
        LFont.Left = 10;
        LFont.Top = 300;
        LFont.Width = 100;
        LFont.Height = 20;
        LFont.ForeColor = System.Drawing.Color.Black;
        this.Controls.Add(LFont);

        CBFonts = new ComboBox();
        CBFonts.Left = 10;
        CBFonts.Top = 320;
        //CBFonts.AllowDrop = true;
        CBFonts.SelectedIndexChanged += CBFonts_Change;
        this.Controls.Add(CBFonts);

        if (Directory.Exists("voc/"))
        {
            fileArray = Directory.GetDirectories("voc");
        }
        else
        {
            Directory.CreateDirectory("voc");
            this.Refresh();
        }

        InstalledFontCollection fontCol = new InstalledFontCollection();
        for (int x = 0; x < fontCol.Families.Length; x++)
        {
            CBFonts.Items.Add(fontCol.Families[x].Name);
        }

        LBDirectory.DataSource = fileArray;
        LBDirectory.Left = 10;
        LBDirectory.Top = 50;
        LBDirectory.Width = 300;
        LBDirectory.Height = 160;
        LBDirectory.HorizontalScrollbar = true;
        LBDirectory.SelectedValueChanged += LBDirectory_ChangeDirectorio;
        LBDirectory.SelectedIndex = dirNumber;
        LBDirectory.ForeColor = System.Drawing.Color.Black;

        TBNewDirectory.Width = 300;
        TBNewDirectory.Height = 30;
        TBNewDirectory.Left = 10;
        TBNewDirectory.Top = 250;

        BUpdate.Left = 340;
        BUpdate.Top = 125;
        BUpdate.Width = 120;
        BUpdate.Height = 25;
        BUpdate.BackColor = System.Drawing.Color.WhiteSmoke;
        BUpdate.ForeColor = System.Drawing.Color.Black;
        BUpdate.Click += BUpdate_Click;

        BSave.Width = 120;
        BSave.Left = 340;
        BSave.Top = 50;
        BSave.UseCompatibleTextRendering = true;
        BSave.Click += BSave_Click;
        BSave.BackColor = System.Drawing.Color.WhiteSmoke;
        BSave.ForeColor = System.Drawing.Color.Black;

        BAddDir.Width = 120;
        BAddDir.Left = 340;
        BAddDir.Top = 250;
        BAddDir.UseCompatibleTextRendering = true;
        BAddDir.Click += BAddDir_Click;
        BAddDir.BackColor = System.Drawing.Color.WhiteSmoke;
        BAddDir.ForeColor = System.Drawing.Color.Black;

        BStudy.Width = 120;
        BStudy.Left = 340;
        BStudy.Top = 75;
        BStudy.UseCompatibleTextRendering = true;

        BStudy.Click += BStudy_Click;
        BStudy.BackColor = System.Drawing.Color.WhiteSmoke;
        BStudy.ForeColor = System.Drawing.Color.Black;

        if (LBDirectory.Items.Count > 0)
        {
            vocDirectory = LBDirectory.SelectedValue.ToString();
        }


        Button BEraseProgress = new Button();
        BEraseProgress.Left = 340;
        BEraseProgress.Top = 150;
        BEraseProgress.Width = 120;
        BEraseProgress.Height = 25;
        BEraseProgress.BackColor = System.Drawing.Color.WhiteSmoke;
        BEraseProgress.ForeColor = System.Drawing.Color.Black;

        BEraseProgress.Click += BEraseProgress_Click;

        this.Controls.Add(BEraseProgress);
        //fontName = CBFonts.SelectedItem.ToString();

        LChoose.Font = new Font(fontName, fontSize + 3);
        LAdd.Font = new Font(fontName, fontSize);
        LFont.Font = new Font(fontName, fontSize);
        BEraseProgress.Font = new Font(fontName, fontSize);
        BSave.Font = new Font(fontName, fontSize);
        BAddDir.Font = new Font(fontName, fontSize);
        BStudy.Font = new Font(fontName, fontSize);
        BUpdate.Font = new Font(fontName, fontSize);

        if (File.Exists("lingua.txt"))
        {
            string[] translations = File.ReadAllLines("lingua.txt", System.Text.Encoding.UTF8);

            LChoose.Text = her.ExtractTranlsation(0);
            LAdd.Text = her.ExtractTranlsation(1);
            LFont.Text = her.ExtractTranlsation(2);
            BSave.Text = her.ExtractTranlsation(3);
            BStudy.Text = her.ExtractTranlsation(4);
            BUpdate.Text = her.ExtractTranlsation(5);
            BEraseProgress.Text = her.ExtractTranlsation(6);
            BAddDir.Text = her.ExtractTranlsation(7);
        }
        else
        {
            LChoose.Text = "Choose directory:";
            LAdd.Text = "Add directory (sin 'voc/'):";
            LFont.Text = "Font:";
            BSave.Text = "Add voc";
            BStudy.Text = "Study";
            BUpdate.Text = "Update library";
            BEraseProgress.Text = "Restart progress";
            BAddDir.Text = "Add";
        }
    }


    void BUpdate_Click(object sender, EventArgs e)
    {

        string[] vocArray = Directory.GetFiles(vocDirectory, "*.txt", SearchOption.TopDirectoryOnly);
        string newList = "";
        //Console.WriteLine(""+vocArray[0]);

        if (vocArray.Length == 1)
        {
            return;
        }

        for (int i = 1; i < vocArray.Length; i++)
        {
            string s = vocArray[i];
            int pFrom = s.IndexOf(vocDirectory) + vocDirectory.Length;
            int pTo = s.LastIndexOf(".txt");
            string ss = s.Substring(pFrom + 1, pTo - pFrom - 1);

            if (i == 1)
            {
                newList += ss + ":0";
            }
            else
            {
                newList += "\n" + ss + ":0";
            }
        }
        File.WriteAllText(vocDirectory + "/00.txt", newList);
        MessageBox.Show("Vocabulary folders have been reset.");
    }
    void BEraseProgress_Click(object sender, EventArgs e)
    {

        string text = File.ReadAllText(vocDirectory + "/00.txt");
        char flag = '\n';
        Console.WriteLine(text);
        File.WriteAllText(vocDirectory + "/00.txt", "");
        string[] textArr = text.Split(flag);
        text = "";
        string s = "";

        for (int i = 0; i < textArr.Length; i++)
        {
            //Console.WriteLine("Entró a for");
            s = textArr[i];
            int iTwoPoints = s.IndexOf(":");
            string numTimes = s.Substring(iTwoPoints + 1, s.Length - iTwoPoints - 1);
            s = s.Replace(numTimes, "0");
            if (i == 0)
            {
                text += s;
            }
            if (i > 0)
            {
                text += "\n" + s;
            }
            //Console.Write(text);
        }
        File.WriteAllText(vocDirectory + "/00.txt", text);
        MessageBox.Show("Vocabulary progress has been reset " + vocDirectory);
    }
    void CBFonts_Change(object sender, EventArgs e)
    {
        fontName = CBFonts.SelectedItem.ToString();

        this.Refresh();

        if (File.Exists("conf.txt"))
        {
            her.ChangeConfFile("conf.txt", 0, CBFonts.SelectedItem.ToString());
        }
    }
    void BStudy_Click(object sender, EventArgs e)
    {
        //vocDirectory = "voc/"+(string)(LBDirectory.SelectedText);

        if (File.ReadAllText(vocDirectory + "/00.txt") != "")
        {
            //Console.WriteLine("Sí hay words");
            AreaDeEstudio AdE = new AreaDeEstudio(fontName, vocDirectory, darkMode);
            AdE.Show();
        }
        else
        {
            MessageBox.Show("There are no words to study, please add them first");
        }
    }
    void BAddDir_Click(object sender, EventArgs e)
    {
        if (TBNewDirectory.Text != "")
        {
            Directory.CreateDirectory("voc/" + TBNewDirectory.Text);
            //File.Create("voc/"+TBNewDirectory.Text+"/lista.txt");
            File.WriteAllText("voc/" + TBNewDirectory.Text + "/00.txt", "");
            TBNewDirectory.Text = "";
            fileArray = Directory.GetDirectories("voc");
            LBDirectory.DataSource = fileArray;
            this.Refresh();
            //this.Update();
        }
    }
    void BSave_Click(object sender, EventArgs e)
    {
        vocDirectory = LBDirectory.SelectedValue.ToString();
        RegistroDiccionario RD = new RegistroDiccionario(fontName, vocDirectory);
        RD.Show();
    }
    void LBDirectory_ChangeDirectorio(object sender, EventArgs e)
    {
        vocDirectory = LBDirectory.SelectedValue.ToString();
        her.ChangeConfFile("conf.txt", 1, "" + LBDirectory.SelectedIndex);
    }

    private void InitializeComponent()
    {
            this.SuspendLayout();
            // 
            // PanelControl
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "PanelControl";
            this.Load += new System.EventHandler(this.PanelControl_Load);
            this.ResumeLayout(false);

    }

    private void PanelControl_Load(object sender, EventArgs e)
    {

    }
}

public class RegistroDiccionario : Form
{
    string fontName;
    string vocDirectory;
    TextBox TBStudyEntry, TBExplanation, TBPhonetic, TBMotherTongue, TBExample;
    Herr her;
    Form FOverWrite;
    Button BSave;


    string file;

    public RegistroDiccionario(string fontName, string vocDirectory)
    {
        this.Icon = new Icon("obento.ico");
        this.MaximizeBox = false;
        this.KeyPreview = true;
        this.KeyDown += Form_KeyPressed;
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.fontName = fontName;
        this.vocDirectory = vocDirectory;
        her = new Herr();
        BackColor = System.Drawing.Color.LightGray;
        Width = 540;
        Height = 600;

        Label LNewWord = new Label();
        Label LLitTranslation = new Label();
        Label LPhonetic = new Label();
        Label LExample = new Label();
        Label LExplanation = new Label();

        Format(LNewWord, "e");
        TBStudyEntry = new TextBox();
        Format(TBStudyEntry, "e");

        Format(LLitTranslation, "m");
        TBMotherTongue = new TextBox();
        Format(TBMotherTongue, "m");

        Format(LPhonetic, "k");
        TBPhonetic = new TextBox();
        Format(TBPhonetic, "k");

        Format(LExample, "ej");
        TBExample = new TextBox();
        Format(TBExample, "ej");

        Format(LExplanation, "expl");
        TBExplanation = new TextBox();
        Format(TBExplanation, "expl");

        BSave = new Button();
        BSave.Width = 120;
        BSave.Left = 380;
        BSave.Top = 520;
        BSave.UseCompatibleTextRendering = true;
        this.Controls.Add(BSave);
        BSave.Font = new Font(fontName, 12);
        BSave.Click += BSave_Click;
        BSave.BackColor = System.Drawing.Color.WhiteSmoke;
        BSave.ForeColor = System.Drawing.Color.Black;

        Button BEditEntry = new Button();
        BEditEntry.Width = 120;
        BEditEntry.Left = 220;
        BEditEntry.Top = 520;

        BEditEntry.UseCompatibleTextRendering = true;
        this.Controls.Add(BEditEntry);
        BEditEntry.Font = new Font(fontName, 12);
        BEditEntry.Click += BEditEntry_Click;
        BEditEntry.BackColor = System.Drawing.Color.WhiteSmoke;
        BEditEntry.ForeColor = System.Drawing.Color.Black;

        if (File.Exists("lingua.txt"))
        {
            this.Text = her.ExtractTranlsation(8);
            BSave.Text = her.ExtractTranlsation(9);
            BEditEntry.Text = her.ExtractTranlsation(10);
            LNewWord.Text = her.ExtractTranlsation(11);
            LLitTranslation.Text = her.ExtractTranlsation(12);
            LPhonetic.Text = her.ExtractTranlsation(13);
            LExample.Text = her.ExtractTranlsation(14);
            LExplanation.Text = her.ExtractTranlsation(15);
        }
        else
        {
            this.Text = vocDirectory;
            BSave.Text = "Add word";
            BEditEntry.Text = "Edit";
            LNewWord.Text = "New word:";
            LLitTranslation.Text = "Literal translation:";
            LPhonetic.Text = "Phonetic:";
            LExample.Text = "Exemple sentence:";
            LExplanation.Text = "Explanation:";
        }
    }

    void BEditEntry_Click(object sender, EventArgs e)
    {
        file = vocDirectory + "/" + TBStudyEntry.Text + ".txt";
        if (File.Exists(file))
        {
            FillRegistry(file);
        }
    }

    void Form_KeyPressed(object sender, KeyEventArgs e)
    {
        if (e.Modifiers == Keys.Control && e.KeyCode == Keys.Enter)
        {
            BSave.PerformClick();
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        if (e.KeyCode == Keys.Enter)
        {
            SendKeys.SendWait("{Tab}");
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
    }

    void BSave_Click(object sender, EventArgs e)
    {
        if (TBPhonetic.Text == "")
        {
            TBPhonetic.Text = "-";
        }
        if (TBExplanation.Text == "")
        {
            TBExplanation.Text = "-";
        }
        if (TBMotherTongue.Text == "")
        {
            TBMotherTongue.Text = "-";
        }
        if (TBExample.Text == "")
        {
            TBExample.Text = "-";
        }

        file = vocDirectory + "/" + TBStudyEntry.Text + ".txt";
        if (!File.Exists(file))
        {
            FileStream fs = File.Create(file);
            //File.Dispose();

            string text = "[N]0[/N]\n"
            + "[V]" + TBStudyEntry.Text + "[/V]\n"
            + "[M]" + TBMotherTongue.Text + "[/M]\n"
            + "[F]" + TBPhonetic.Text + "[/F]\n"
            + "[O]" + TBExample.Text + "[/O]\n"
            + "[E]" + TBExplanation.Text + "[/E]\n";
            fs.Dispose();

            StreamWriter SW = new StreamWriter(file);
            SW.Write(text);
            SW.Dispose();

            string entry;
            if (File.ReadAllText(vocDirectory + "/00.txt") == "")
            {
                entry = TBStudyEntry.Text + ":0";
            }
            else
            {
                entry = "\n" + TBStudyEntry.Text + ":0";
            }

            SW = File.AppendText(vocDirectory + "/00.txt");
            SW.Write(entry);
            SW.Dispose();

            TBStudyEntry.Text = "";
            TBMotherTongue.Text = "";
            TBExplanation.Text = "";
            TBExample.Text = "";
            TBPhonetic.Text = "";

        }
        else if (File.Exists(file))
        {

            FOverWrite = new Form();

            Button BOverWrite = new Button();
            BOverWrite.Text = "Over Write";
            BOverWrite.BackColor = System.Drawing.Color.LightGray;
            BOverWrite.ForeColor = System.Drawing.Color.Black;
            BOverWrite.Height = 30;
            BOverWrite.Width = 120;
            BOverWrite.Left = 40;
            BOverWrite.Top = 30;
            BOverWrite.Click += BOverWrite_Click;

            Button BEdit = new Button();
            BEdit.Text = "Edit";
            BEdit.BackColor = System.Drawing.Color.LightGray;
            BEdit.ForeColor = System.Drawing.Color.Black;
            BEdit.Height = 30;
            BEdit.Width = 120;
            BEdit.Left = 40;
            BEdit.Top = 100;
            BEdit.Click += BEdit_Click;
            //BEdit.FlatStyle = FlatStyle.System;

            FOverWrite.Width = 200;
            FOverWrite.Height = 220;
            FOverWrite.Show();

            FOverWrite.Controls.Add(BOverWrite);
            FOverWrite.Controls.Add(BEdit);
        }
    }
    void BOverWrite_Click(object sender, EventArgs e)
    {
        File.Delete(file);
        FileStream fs = File.Create(file);

        if (TBPhonetic.Text == "")
        {
            TBPhonetic.Text = "-";
        }
        if (TBExplanation.Text == "")
        {
            TBPhonetic.Text = "-";
        }
        if (TBMotherTongue.Text == "")
        {
            TBMotherTongue.Text = "-";
        }
        if (TBExample.Text == "")
        {
            TBExample.Text = "-";
        }

        string text = "[N]0[/N]\n"
        + "[V]" + TBStudyEntry.Text + "[/V]\n"
        + "[M]" + TBMotherTongue.Text + "[/M]\n"
        + "[F]" + TBPhonetic.Text + "[/F]\n"
        + "[O]" + TBExample.Text + "[/O]\n"
        + "[E]" + TBExplanation.Text + "[/E]\n";
        fs.Dispose();

        StreamWriter SW = new StreamWriter(file);
        SW.Write(text);
        SW.Dispose();

        string entry = "";

        if (!File.Exists(vocDirectory + "/00.txt"))
        {
            File.WriteAllText(vocDirectory + "/00.txt", "");
        }

        if (File.ReadAllText(vocDirectory + "/00.txt").Contains(TBStudyEntry.Text))
        {
            //entry = TBStudyEntry.Text+":0";
        }
        else
        {
            entry = "\n" + TBStudyEntry.Text + ":0";
            SW = File.AppendText(vocDirectory + "/00.txt");
            SW.Write(entry);
            SW.Dispose();
        }

        TBStudyEntry.Text = "";
        TBMotherTongue.Text = "";
        TBExplanation.Text = "";
        TBExample.Text = "";
        TBPhonetic.Text = "";

        FOverWrite.Dispose();
    }

    void BEdit_Click(object sender, EventArgs e)
    {
        FOverWrite.Dispose();
        FillRegistry(file);
    }

    public void FillRegistry(string file)
    {
        Herr her = new Herr();
        string alltext = her.ImportText(file);
        RegistroDiccionario RD = new RegistroDiccionario(fontName, vocDirectory);
        RD.Controls[1].Text = her.ExtractText(alltext, "V");
        RD.Controls[3].Text = her.ExtractText(alltext, "M");
        RD.Controls[5].Text = her.ExtractText(alltext, "F");
        RD.Controls[7].Text = her.ExtractText(alltext, "O");
        RD.Controls[9].Text = her.ExtractText(alltext, "E");

        RD.Show();
    }

    public void Format(TextBox TB, string type)
    {
        TB.Left = 12;
        TB.Font = new Font(fontName, 20);
        //TB.FlatStyle = FlatStyle.Flat;

        if (type == "e")
        {
            TB.Top = 35;
            TB.Width = 240;
        }
        if (type == "m")
        {
            TB.Top = 100;
            TB.Width = 240;
        }
        if (type == "k")
        {
            TB.Top = 100;
            TB.Left += 300;
            TB.Width = 200;
        }
        if (type == "ej")
        {
            TB.Multiline = true;
            TB.Top = 170;
            TB.Height = 90;
            TB.Width = 500;
        }
        if (type == "expl")
        {
            TB.Multiline = true;
            TB.Top = 290;
            TB.Height = 220;
            TB.Width = 500;
        }
        this.Controls.Add(TB);
    }

    public void Format(Label L, string type)
    {
        L.Left = 12;
        L.ForeColor = System.Drawing.Color.Black;
        L.Font = new Font(fontName, 15);

        if (type == "e")
        {
            L.Top = 10;
            L.Width = 200;
        }
        if (type == "m")
        {
            L.Top = 75;
            L.Width = 200;
        }
        if (type == "k")
        {
            L.Top = 75;
            L.Left += 300;
            L.Width = 120;
        }
        if (type == "ej")
        {
            L.Top = 145;
            L.Width = 200;
        }
        if (type == "expl")
        {
            L.Top = 265;
            L.Width = 240;
        }
        this.Controls.Add(L);
    }
}


public class AreaDeEstudio : Form
{

    string[] word;
    string alltext;
    string answer = "";
    string expectedAnswer = "";
    int mode = 0;
    int points = 5;
    string cmode = "O";
    int numTimes;
    string studySentence = "";
    string fontName;
    string vocDirectory;
    Color backColour;
    Color leterColour;
    Color buttonColour;
    TextBox TBanswer;
    Button Bmode;
    Button BHint;
    Button BNext;
    Button BdarkMode;
    Label LSentences;
    Label LFrame;
    bool darkMode;
    Herr her;

    public AreaDeEstudio(string fontName, string vocDirectory, bool darkMode)
    {
        this.darkMode = darkMode;
        this.Icon = new Icon("obento.ico");
        backColour = System.Drawing.Color.LightGray;
        buttonColour = System.Drawing.Color.WhiteSmoke;
        leterColour = System.Drawing.Color.Black;

        this.fontName = fontName;
        this.vocDirectory = vocDirectory;
        her = new Herr();
        //this.WindowState = FormWindowState.Maximized;
        this.Width = 1080;
        this.Height = 600;

        this.Resize += ChangeSize;
        this.DoubleBuffered = true;

        Bmode = new Button();
        TBanswer = new TextBox();
        LSentences = new Label();
        BNext = new Button();
        LFrame = new Label();


        Bmode.BackColor = System.Drawing.Color.LightGray;
        Bmode.ForeColor = System.Drawing.Color.Black;
        Bmode.Click += Bmode_Click;
        this.Controls.Add(Bmode);

        TBanswer.Text = "";
        TBanswer.Font = new Font(fontName, 35);
        //TBanswer.FlatStyle = FlatStyle.Flat;
        //TBanswer.Bord = 0;
        TBanswer.TextChanged += TBanswer_textChange;
        TBanswer.KeyDown += TBanswer_BotonPresionado;
        this.Controls.Add(TBanswer);

        LSentences.Font = new Font(fontName, 40);

        //LSentences.BackColor = System.Drawing.Color.CornflowerBlue;
        this.Controls.Add(LSentences);

        BHint = new Button();


        BHint.Click += BHint_Click;
        this.Controls.Add(BHint);

        BNext.BackColor = System.Drawing.Color.LightGray;
        BNext.ForeColor = System.Drawing.Color.Black;
        BNext.Click += BNext_Click;
        this.Controls.Add(BNext);

        BdarkMode = new Button();
        BdarkMode.BackColor = System.Drawing.Color.LightGray;
        BdarkMode.ForeColor = System.Drawing.Color.Black;
        BdarkMode.Click += BdarkMode_Click;
        this.Controls.Add(BdarkMode);

        this.Controls.Add(LFrame);

        if (File.Exists("lingua.txt"))
        {
            this.Text = her.ExtractTranlsation(16);
            BdarkMode.Text = her.ExtractTranlsation(17);
            BNext.Text = her.ExtractTranlsation(18);
            BHint.Text = her.ExtractTranlsation(19);
            LSentences.Text = her.ExtractTranlsation(20);
            Bmode.Text = her.ExtractTranlsation(21);

        }
        else
        {
            BdarkMode.Text = "mode Oscuro";
            BNext.Text = "Siguiente";
            BHint.Text = "Mostrar answer";
            LSentences.Text = "Muy buenas noches";
            Bmode.Text = "Cambiar mode estudio";
            this.Text = "Área de estudio";
        }


        Format();
        UpdateWord();
    }
    void BHint_Click(object sender, EventArgs e)
    {
        TBanswer.Text = expectedAnswer;
        TBanswer.BackColor = System.Drawing.Color.MediumPurple;
        points = 5;
    }

    void BdarkMode_Click(object sender, EventArgs e)
    {

        if (darkMode)
        {
            her.ChangeConfFile("conf.txt", 2, "0");
            darkMode = false;

        }
        else
        {
            her.ChangeConfFile("conf.txt", 2, "1");
            darkMode = true;
        }


        Format();
    }

    bool UpdateWord()
    {
        word = her.LeastStudiedWord(vocDirectory);
        Random rand = new Random();

        switch (mode)
        {
            case 0: //mode Oracioón ______ word faltante
                expectedAnswer = word[0];
                cmode = "O";
                break;
            case 1: //mode lectura Kanji
                cmode = "F";
                //Console.WriteLine(word[0]);
                expectedAnswer = her.ExtractText(her.ImportText(vocDirectory + "/" + word[0] + ".txt"), cmode);
                //Console.WriteLine(expectedAnswer);
                break;
            case 2://mode leer explicación
                cmode = "E";
                expectedAnswer = word[0];
                break;
            case 3://mode leer en lengua materna
                cmode = "M";
                expectedAnswer = word[0];
                break;
        }

        alltext = her.ImportText(vocDirectory + "/" + word[0] + ".txt");
        string studySentence = "";


        if (mode == 0)
        {
            studySentence = her.ExtractText(alltext, cmode);
            studySentence = studySentence.Replace(word[0], "_____");
            Bmode.Text = "Fill ___";
            points = 5 + rand.Next(0, 5);

        }
        if (mode == 1)
        {
            studySentence = word[0];
            Bmode.Text = "Phonetic";
            points = 5 + rand.Next(0, 5);

        }
        if (mode == 2)
        {
            studySentence = her.ExtractText(alltext, cmode);
            Bmode.Text = "Explanation";
            points = 5 + rand.Next(0, 5);

        }
        if (mode == 3)
        {
            studySentence = her.ExtractText(alltext, cmode);
            Bmode.Text = "Translation";
            points = 5 + rand.Next(0, 5);
        }

        if (File.Exists("lingua.txt"))
        {
            string[] translations = File.ReadAllLines("lingua.txt", System.Text.Encoding.UTF8);

            Bmode.Text = translations[22 + mode];
        }
        LSentences.Text = studySentence;
        return true;
    }

    void ChangeSize(object sender, EventArgs e)
    {
        //Console.WriteLine("Change de tamaño");
        Format();
    }
    void Format()
    {

        if (darkMode)
        {
            backColour = System.Drawing.Color.FromArgb(255, 0, 31, 51);
            leterColour = System.Drawing.Color.WhiteSmoke;
            buttonColour = System.Drawing.Color.FromArgb(255, 0, 26, 51);

        }
        else
        {
            backColour = System.Drawing.Color.LightGray;
            leterColour = System.Drawing.Color.Black;
            buttonColour = System.Drawing.Color.WhiteSmoke;
        }

        Color color = new Color();
        switch (mode)
        {
            case 0:
                if (darkMode)
                {
                    color = System.Drawing.Color.Brown;
                }
                else
                {
                    color = System.Drawing.Color.LightCoral;
                }

                break;
            case 1:

                if (darkMode)
                {
                    color = System.Drawing.Color.CornflowerBlue;
                }
                else
                {
                    color = System.Drawing.Color.CornflowerBlue;
                }

                break;
            case 2:

                if (darkMode)
                {
                    color = System.Drawing.Color.DarkOrange;
                }

                else
                {
                    color = System.Drawing.Color.Orange;
                }
                break;
            case 3:

                if (darkMode)
                {
                    color = System.Drawing.Color.LightGreen;
                }
                else
                {
                    color = System.Drawing.Color.LightGreen;
                }
                break;
        }


        BdarkMode.FlatStyle = FlatStyle.Flat;
        BdarkMode.FlatAppearance.BorderSize = 2;
        BdarkMode.FlatAppearance.BorderColor = color;

        BNext.FlatStyle = FlatStyle.Flat;
        BNext.FlatAppearance.BorderSize = 2;
        BNext.FlatAppearance.BorderColor = color;

        Bmode.FlatStyle = FlatStyle.Flat;
        Bmode.FlatAppearance.BorderSize = 2;
        Bmode.FlatAppearance.BorderColor = color;

        BHint.FlatStyle = FlatStyle.Flat;
        BHint.FlatAppearance.BorderSize = 2;
        BHint.FlatAppearance.BorderColor = color;

        this.BackColor = backColour;

        LFrame.Height = this.Height / 2 + 40;
        LFrame.Width = 10 * this.Width / 12 + 40;
        LFrame.Left = this.Width / 12 - 20;
        LFrame.Top = 20;
        LFrame.AutoSize = false;
        LFrame.BackColor = color;

        LSentences.Height = this.Height / 2;
        LSentences.Width = 10 * this.Width / 12; ;
        LSentences.Left = this.Width / 12;
        LSentences.Top = 40;
        LSentences.AutoSize = false;
        LSentences.BackColor = buttonColour;
        LSentences.ForeColor = leterColour;
        LSentences.TextAlign = ContentAlignment.MiddleCenter;

        TBanswer.Height = this.Height / 8;
        TBanswer.Width = this.Width / 3;
        TBanswer.Left = this.Width / 3;
        TBanswer.Top = 2 * this.Height / 3;
        TBanswer.TextAlign = HorizontalAlignment.Center;

        Bmode.Height = this.Height / 12;
        Bmode.Width = this.Width / 9;
        Bmode.Left = this.Width / 3;
        Bmode.Top = this.Height * 19 / 24;
        Bmode.BackColor = buttonColour;
        Bmode.ForeColor = leterColour;

        BNext.Height = this.Height / 12;
        BNext.Width = this.Width / 9;
        BNext.Left = +this.Width / 3 + this.Width / 9; ;
        BNext.Top = this.Height * 19 / 24;
        BNext.BackColor = buttonColour;
        BNext.ForeColor = leterColour;

        BdarkMode.Height = this.Height / 24;
        BdarkMode.Width = this.Width / 9;
        BdarkMode.Left = +this.Width / 3 + this.Width / 9; ;
        BdarkMode.Top = this.Height * 21 / 24 + 5;
        BdarkMode.BackColor = buttonColour;
        BdarkMode.ForeColor = leterColour;

        BHint.Height = this.Height / 12;
        BHint.Width = this.Width / 9;
        BHint.Left = this.Width / 3 + this.Width * 2 / 9; ;
        BHint.Top = this.Height * 19 / 24;
        BHint.BackColor = buttonColour;
        BHint.ForeColor = leterColour;

        TBanswer.Select();
        this.Refresh();
    }

    void TBanswer_BotonPresionado(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            BNext_Click(this, new EventArgs());
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
    }

    void TBanswer_textChange(object sender, EventArgs e)
    {
        answer = TBanswer.Text;
        if (answer == expectedAnswer)
        {
            TBanswer.BackColor = System.Drawing.Color.LightGreen;
        }
        else
        {
            TBanswer.BackColor = System.Drawing.Color.White;
        }
    }

    bool CheckAnswer()
    {
        numTimes = Int32.Parse(word[1]);
        if (answer == "")
        {
            string text = Regex.Replace("\n" + File.ReadAllText(vocDirectory + "/00.txt"), "\n" + word[0] + ":" + numTimes, "\n" + word[0] + ":" + (numTimes + 10));
            text = text.Substring(1);
            File.WriteAllText(vocDirectory + "/00.txt", text);
            return true;
        }
        if (answer == expectedAnswer)
        {
            string text = Regex.Replace("\n" + File.ReadAllText(vocDirectory + "/00.txt"), "\n" + word[0] + ":" + numTimes, "\n" + word[0] + ":" + (numTimes + points));
            text = text.Substring(1);
            File.WriteAllText(vocDirectory + "/00.txt", text);

            //Console.Beep(440, 200);
            //Console.Beep(37, 50);
            //Console.Beep(600, 300);

            return true;
        }
        else
        {
            if (TBanswer.BackColor == System.Drawing.Color.FromArgb(255, 255, 51, 51))
            {
                return true;
            }
            //Console.Beep(440, 200);
            //Console.Beep(440, 200);
            return false;
        }




    }

    void Bmode_Click(object sender, EventArgs e)
    {
        if (mode == 0)
        {
            mode++;
        }
        else if (mode == 1)
        {
            mode++;
        }
        else if (mode == 2)
        {
            mode++;
        }
        else if (mode == 3)
        {
            mode = 0;
        }
        UpdateWord();
        Format();
        this.Refresh();
    }

    void BNext_Click(object sender, EventArgs e)
    {
        if (!CheckAnswer())
        {
            TBanswer.BackColor = System.Drawing.Color.FromArgb(255, 255, 51, 51);
        }
        else
        {
            UpdateWord();
            TBanswer.Select();
            TBanswer.Text = "";
        }

    }
}

public class Herr
{
    public void ChangeConfFile(string dir, int line, string entry)
    {
        string[] textConfigCompleto = File.ReadAllLines(dir);
        textConfigCompleto[line] = entry;
        File.WriteAllLines(dir, textConfigCompleto);
    }
    public string ImportText(string file)
    {
        string text = File.ReadAllText(file);
        return text;
    }
    public string[] ExtractLeastStudiedWord(string alltext)
    {
        char flag = '\n';
        string[] textArr = alltext.Split(flag);
        string[] text = new string[textArr.Length];
        int[] numb = new int[textArr.Length];
        //Console.WriteLine("Num words:"+(textArr.Length-1));

        for (int i = 0; i < textArr.Length; i++)
        {
            int nDosPunts = textArr[i].IndexOf(":");
            text[i] = textArr[i].Substring(0, nDosPunts);
            //Console.WriteLine(i+":"+text[i]);
            numb[i] = Int32.Parse(textArr[i].Substring(nDosPunts + 1));
            //Console.WriteLine(i+":"+numb[i]);
        }
        //Console.WriteLine("último:"+text[textArr.Length-2]+","+numb[textArr.Length-2]);
        string[] temp = { text[IndexOfMin(numb)], "" + numb[IndexOfMin(numb)] };
        //Console.WriteLine("Regreso:"+temp[0]+","+temp[1]);
        return temp;
    }
    public string ExtractText(string alltext, string flag)
    {
        string[] flags = { "[" + flag + "]", "[/" + flag + "]" };
        string[] textArr = alltext.Split(flags, System.StringSplitOptions.RemoveEmptyEntries);
        if (flag == "N")
        {
            return textArr[0];
        }
        else
        {
            return textArr[1];
        }
    }
    public string[] LeastStudiedWord(string vocDirectory)
    {
        string[] textnumb = new string[2];
        textnumb = ExtractLeastStudiedWord(ImportText(vocDirectory + "/00.txt"));
        //Console.WriteLine("text y número recibidos");
        return textnumb;

    }

    public string ExtractTranlsation(int line)
    {
        string textTranslation = ImportText("lingua.txt");
        string[] textArr = textTranslation.Split('\n');
        return textArr[line];
    }
    public static int IndexOfMin(int[] source)
    {
        if (source == null)
            throw new ArgumentNullException("source");

        int minValue = int.MaxValue;
        int minIndex = -1;
        int index = -1;

        foreach (int num in source)
        {
            index++;

            if (num <= minValue)
            {
                minValue = num;
                minIndex = index;
            }
        }

        if (index == -1)
            throw new InvalidOperationException("Sequence was empty");

        return minIndex;
    }
}
